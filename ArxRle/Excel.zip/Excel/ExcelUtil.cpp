// ********************************************************************************************
// * $RCSfile: $
// * 
// * Programm     : ExcelUtil.cpp
// * Programmierer: 000
// * Erzeugt      : 2008-8-22 TKL
// * 
// * $Name: $
// * $Revision: 6 $
// * $Date: 11-03-24 10:26 $
// * $Source: $
// * $State: $
// *  
// * $ProjectRevision: $
// *  
// ********************************************************************************************
// *  
// * Funktion: implementation of the CExcelUtil class.
// *  
// ********************************************************************************************
// * 
// * Umgebung: Windows NT 4.0, Microsoft Developer Studio 6.0
// * 
// ********************************************************************************************
// * 
// * �nderungen: 
// * 
// * $Log: /Dev/Vers_82/BasedataManager/BasedataManager/ExcelUtil/ExcelUtil.cpp $
//* 
//* 6     11-03-24 10:26 Mashuangqin
//* 
//* 5     09-11-04 16:54 Zhangl
//* 
//* 4     09-04-24 16:02 Zhangl
//* ֧��Excel2007
//* 
//* 3     08-09-01 17:28 Zhangl
//* ֧��Excel2007
//* 
//* 2     08-08-29 12:09 Zhangl
//* ֧��Excel 2000 2003 2007
//* 
//* 1     08-08-28 10:49 Zhangl
//* ֧��Excel2007
//* 
//* 1     08-08-27 12:33 Zhangl
//* Excel����
// * 
// ********************************************************************************************
// * 
// *(C) IB&T GmbH
// * 
// ********************************************************************************************

#include "stdafx.h"
#include "ExcelUtil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#pragma warning(disable:4311) //ȫ���ص�

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExcelUtil::CExcelUtil()
{
    m_covTrue = COleVariant((short)TRUE);
    m_covFalse = COleVariant((short)FALSE);
    m_covOptional = COleVariant((long)DISP_E_PARAMNOTFOUND, VT_ERROR);
}

CExcelUtil::~CExcelUtil()
{
    m_Range.ReleaseDispatch();
    m_Sheet.ReleaseDispatch();
    m_Sheets.ReleaseDispatch();
    m_Book.ReleaseDispatch();
    m_Books.ReleaseDispatch(); 
}

void CExcelUtil::InitExcel()
{
    //����Excel������(����Excel) 
    if(!m_ExcelApp.CreateDispatch(_T("Excel.Application"), NULL)) 
    {
        AfxMessageBox(_T("Fail To Create Excel Server!\r\nPlease Confirm Excel Is Installed Successfully!"));
        exit(1);
    }
}

void CExcelUtil::ReleaseExcel()
{
	m_ExcelApp.Quit();
	m_Querys.ReleaseDispatch();
	m_Query.ReleaseDispatch();
	m_Range.ReleaseDispatch();
	m_Sheet.ReleaseDispatch();
	m_Sheets.ReleaseDispatch();
	m_Book.ReleaseDispatch();
	m_Books.ReleaseDispatch();
	m_ExcelApp.ReleaseDispatch();
}

void CExcelUtil::DetachExcel()
{
	m_Querys.DetachDispatch();
	m_Query.DetachDispatch();
	m_Range.DetachDispatch();
	m_Sheet.DetachDispatch();
	m_Sheets.DetachDispatch();
	m_Book.DetachDispatch();
	m_Books.DetachDispatch();
	m_ExcelApp.DetachDispatch();
}

void CExcelUtil::CloseAlert()
{
	m_ExcelApp.SetAlertBeforeOverwriting(FALSE);
	m_ExcelApp.SetDisplayAlerts(FALSE);
}

BOOL CExcelUtil::CreateExcel(CString strFileName)
{
    try
    {
        if(strFileName.IsEmpty())
        {
            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(m_covOptional));
            m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
            return TRUE;
        }
        else
        {
            if(FindFile(strFileName))
            {
                CString strWarning;
                //CString strOverWriteWarning;
                //strOverWriteWarning.LoadString(IDS_STRING_WARNING_OVERWRITE);
                strWarning.Format(_T("%s �Ѿ�����, ȷ������?"), strFileName);
                if(IDYES == AfxMessageBox(strWarning, MB_YESNO | MB_ICONINFORMATION))
                {
                    //����ɾ���ļ��Է��ײ���ʾ����
                    DeleteFile(strFileName);
                    m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
                    m_Book.AttachDispatch(m_Books.Add(m_covOptional));
                    m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
					SaveAs(strFileName);
                    return TRUE;
                }
                else
                {
                    CloseExcel();
                    ReleaseExcel();
                    return FALSE;
                }
            }

            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(m_covOptional));
            m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
			SaveAs(strFileName);
            return TRUE;
        }
    }
    catch(CException* e)
    {
        e->Delete();
        CloseExcel();
        ReleaseExcel();
        return FALSE;
    }
}

BOOL CExcelUtil::CreateExcel(CString strFileName, CString strFilePath)
{   
    try
    {
        if(strFileName.IsEmpty())
        {
            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(m_covOptional));
            return TRUE;
        }
        else
        {
            if(FindPathEndChar(strFilePath))
            {
                strFileName = strFilePath + strFileName;
            }
            else
            {
                strFileName = strFilePath + _T("\\") + strFileName;
            }
            
            if(FindFile(strFileName))
            {
                CString strWarning;
                //CString strOverWriteWarning;
                //strOverWriteWarning.LoadString(IDS_STRING_WARNING_OVERWRITE);
                strWarning.Format(_T("%s �Ѿ�����, ȷ������?"), strFileName);
                if(IDYES == AfxMessageBox(strWarning, MB_YESNO | MB_ICONINFORMATION))
                {
                    //����ɾ���ļ��Է��ײ���ʾ����
                    DeleteFile(strFileName);
                    m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
                    m_Book.AttachDispatch(m_Books.Add(m_covOptional));
                    m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
					SaveAs(strFileName);
                    return TRUE;
                }
                else
                {
                    CloseExcel();
                    ReleaseExcel();
                    return FALSE;
                }
            }

            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(m_covOptional));
            m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
			SaveAs(strFileName);
            return TRUE;
        }
    }
    catch(CException* e)
    {
        e->Delete();
        CloseExcel();
        ReleaseExcel();
        return FALSE;
    }
}

BOOL CExcelUtil::CreateExcel(CString strFileName, CString strFilePath, CString strTplName, CString strTplPath)
{
    //����ģ���ļ�������Excel
    strTplName = strTplPath + _T("\\") + strTplName;
    try
    {
        if(strFileName.IsEmpty())
        {
            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(_variant_t(strTplName)), TRUE);
            m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
            return TRUE;
        }
        else
        {
            if(FindPathEndChar(strFilePath))
            {
                strFileName = strFilePath + strFileName;
            }
            else
            {
                strFileName = strFilePath + _T("\\") + strFileName;
            }

            if(FindFile(strFileName))
            {
                CString strWarning;
                strWarning.Format(_T("%s �Ѿ�����, ȷ������?"), strFileName);
                if(IDYES == AfxMessageBox(strWarning, MB_YESNO | MB_ICONINFORMATION))
                {
                    //����ɾ���ļ��Է��ײ���ʾ����
                    DeleteFile(strFileName);
                    m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
                    m_Book.AttachDispatch(m_Books.Add(_variant_t(strTplName)), TRUE);
                    m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
					SaveAs(strFileName);
                    return TRUE;
                }
                else
                {
                    CloseExcel();
                    ReleaseExcel();
                    return FALSE;
                }
            }

            m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
            m_Book.AttachDispatch(m_Books.Add(_variant_t(strTplName)), TRUE);
            m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE);
			SaveAs(strFileName);
            return TRUE;
        }
    }
    catch(CException* e)
    {
        e->Delete();
        CloseExcel();
        ReleaseExcel();
        return FALSE;
    }
}

BOOL CExcelUtil::OpenExcel(CString strFileName)
{
    //��excel�ļ�
    //����ģ���ļ��������ĵ�
    m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
    LPDISPATCH lpDis = NULL;
    lpDis = m_Books.Open(strFileName, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, 
        m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional);
    if(lpDis)
    {
        m_Book.AttachDispatch(lpDis); 
        //�õ�Worksheets 
        m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE); 
        return TRUE;
    }
    
    return FALSE;
}

BOOL CExcelUtil::OpenExcel(CString strFileName, CString strFilePath)
{
    //��excel�ļ�
    strFileName = strFilePath + _T("\\") + strFileName;
    //����ģ���ļ��������ĵ�
    m_Books.AttachDispatch(m_ExcelApp.GetWorkbooks(), TRUE);
    LPDISPATCH lpDis = NULL;
    lpDis = m_Books.Open(strFileName, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, 
        m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional);
    if(lpDis)
    {
        m_Book.AttachDispatch(lpDis); 
        //�õ�Worksheets
        m_Sheets.AttachDispatch(m_Book.GetWorksheets(), TRUE); 
        return TRUE;
    }
    
    return FALSE;
}

BOOL CExcelUtil::FindFile(CString strFileName)
{
    WIN32_FIND_DATA   FindFileData;
    HANDLE   hFile = INVALID_HANDLE_VALUE;

    hFile = FindFirstFile(strFileName, &FindFileData);

    if(hFile == INVALID_HANDLE_VALUE)
    {
        FindClose(hFile);
        return FALSE;
    }
    FindClose(hFile);

    return TRUE;
}

BOOL CExcelUtil::FindFile(CString strFilePath, CString strFileName)
{
    WIN32_FIND_DATA   FindFileData;
    HANDLE   hFile = INVALID_HANDLE_VALUE;

    strFileName = strFilePath + _T("\\")+ strFileName;

    hFile = FindFirstFile(strFileName, &FindFileData);

    if(hFile == INVALID_HANDLE_VALUE)
    {
        FindClose(hFile);
        return FALSE;
    }
    FindClose(hFile);

    return TRUE;
}

void CExcelUtil::DeleteFile(CString strFileName)
{
    if(FALSE == FindFile(strFileName))
    {
        return;
    }

    CFile::Remove(strFileName);
}

void CExcelUtil::DeleteFile(CString strFilePath, CString strFileName)
{
    if(FALSE == FindFile(strFileName))
    {
        return;
    }

    strFileName = strFilePath + _T("\\") + strFileName;
    CFile::Remove(strFileName);
}

void CExcelUtil::ShowExcel(BOOL bShow)
{
    m_ExcelApp.SetVisible(bShow);
}

void CExcelUtil::Save()
{
    m_Book.Save();
}

void CExcelUtil::SaveAs(CString &strFileName)
{
    m_Book.SaveAs(COleVariant(strFileName), m_covOptional, m_covOptional, m_covOptional,
        m_covOptional, m_covOptional, 1, m_covOptional, m_covOptional, m_covOptional, m_covOptional, m_covOptional);
}

void CExcelUtil::CloseExcel()
{
    m_Book.Close(m_covOptional, COleVariant(_T("")), m_covOptional);
    m_Books.Close();
}

BOOL CExcelUtil::AddSheet(CString strSheetName)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	LoadSheet(GetSheetCount());
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);   
	m_Sheets.Add(covOptional, covOptional, covOptional, covOptional);
	LoadSheet(GetSheetCount());
	m_Sheet.SetName(strSheetName);

	return TRUE;
}

BOOL CExcelUtil::AddSheet(CString strSheetName, int iIndex)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	LoadSheet(iIndex);
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);   
	m_Sheets.Add(covOptional, covOptional, covOptional, covOptional);
	LoadSheet(iIndex+1);
	m_Sheet.SetName(strSheetName);

	return TRUE;
}

BOOL CExcelUtil::AddSheet(CString strSheetName, CString strSheetTpl)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	LoadSheet(strSheetTpl);
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);   
	m_Sheets.Add(covOptional, covOptional, covOptional, covOptional);
	LoadSheet(GetSheetIndex(strSheetTpl)+1);
	m_Sheet.SetName(strSheetName);

	return TRUE;
}

BOOL CExcelUtil::LoadSheet(int iIndex)
{
    if(1 > iIndex)
    {
        //��������ȷ������FALSE
        AfxMessageBox(_T("Min sheet number is 1!"));
        return FALSE;
    }
    if(GetSheetCount() < iIndex)
    {
        //�����sheet����������sheet��
        return FALSE;
    }

    LPDISPATCH lpDis = NULL;
    m_Range.ReleaseDispatch();
    m_Sheet.ReleaseDispatch();
    lpDis = m_Sheets.GetItem(_variant_t((long)iIndex));
    if(lpDis)
    {
        m_Sheet.AttachDispatch(lpDis, TRUE);
		m_Sheet.Activate();
        m_Range.AttachDispatch(m_Sheet.GetCells(), TRUE);
        return TRUE;
    }
    return FALSE;
}

BOOL CExcelUtil::LoadSheet(CString strSheetName)
{
    if(strSheetName.IsEmpty())
        return FALSE;

    m_Range.ReleaseDispatch();
    m_Sheet.ReleaseDispatch();
    LPDISPATCH lpDis = NULL;
    //�¼���Sheet
    lpDis = m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString()));
    if(lpDis)
    {
        m_Sheet.AttachDispatch(lpDis, TRUE);
		m_Sheet.Activate();
        m_Range.AttachDispatch(m_Sheet.GetCells(), TRUE);
    }

    return TRUE;
}

BOOL CExcelUtil::DeleteSheet(int iIndex)
{
	if(1 > iIndex)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min sheet number is 1!"));
		return FALSE;
	}

	if(GetSheetCount() < iIndex)
		return FALSE;

	CloseAlert();
	CloseAlert();
	LoadSheet(iIndex);
	m_Sheet.Delete();

	return TRUE;
}

BOOL CExcelUtil::DeleteSheet(CString strSheetName)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	CloseAlert();
	for (int i=1; i<=GetSheetCount(); ++i)
	{
		LoadSheet(i);
		if(GetSheetName(i) == strSheetName)
			m_Sheet.Delete();
	}

	return TRUE;
}

BOOL CExcelUtil::MoveSheet(int iIndex1, int iIndex2)
{
	if(1 > iIndex1 || 1 > iIndex2)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min sheet number is 1!"));
		return FALSE;
	}
	if(GetSheetCount() < iIndex1 || GetSheetCount() < iIndex2)
	{
		//�����sheet����������sheet��
		return FALSE;
	}

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t((long)iIndex1));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		lpDis = m_Sheets.GetItem(_variant_t((long)(iIndex2)));
		if(lpDis)
		{
			sheet.AttachDispatch(lpDis, TRUE);
			m_Sheet.Move(vtMissing, _variant_t(sheet));
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::MoveSheetFirst(int iIndex)
{
	if(1 > iIndex)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min sheet number is 1!"));
		return FALSE;
	}
	if(GetSheetCount() < iIndex)
	{
		//�����sheet����������sheet��
		return FALSE;
	}

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t((long)iIndex));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		if(iIndex > 1)
		{
			lpDis = m_Sheets.GetItem(_variant_t((long)(1)));
			if(lpDis)
			{
				sheet.AttachDispatch(lpDis, TRUE);
				m_Sheet.Move(_variant_t(sheet),vtMissing);
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::MoveSheetLast(int iIndex)
{
	if(1 > iIndex)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min sheet number is 1!"));
		return FALSE;
	}
	if(GetSheetCount() < iIndex)
	{
		//�����sheet����������sheet��
		return FALSE;
	}

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t((long)iIndex));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		int cnt = GetSheetCount();
		if(iIndex < cnt)
		{
			lpDis = m_Sheets.GetItem(_variant_t((long)(cnt)));
			if(lpDis)
			{
				sheet.AttachDispatch(lpDis, TRUE);
				m_Sheet.Move(vtMissing, _variant_t(sheet));
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::MoveSheet(CString strSheetName1, CString strSheetName2)
{
	if(strSheetName1.IsEmpty() || strSheetName2.IsEmpty())
		return FALSE;

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t(strSheetName1.AllocSysString()));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		lpDis = m_Sheets.GetItem(_variant_t(strSheetName2.AllocSysString()));
		if(lpDis)
		{
			sheet.AttachDispatch(lpDis, TRUE);
			m_Sheet.Move(vtMissing, _variant_t(sheet));
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::MoveSheetFirst(CString strSheetName)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString()));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		int idx = m_Sheet.GetIndex();
		if(idx > 1)
		{
			lpDis = m_Sheets.GetItem(_variant_t((long)(1)));
			if(lpDis)
			{
				sheet.AttachDispatch(lpDis, TRUE);
				m_Sheet.Move(_variant_t(sheet),vtMissing);
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::MoveSheetLast(CString strSheetName)
{
	if(strSheetName.IsEmpty())
		return FALSE;

	LPDISPATCH lpDis = NULL;
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString()));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		_Worksheet sheet;
		sheet.ReleaseDispatch();
		int idx = GetSheetIndex(strSheetName);
		int cnt = GetSheetCount();
		if(idx < cnt)
		{
			lpDis = m_Sheets.GetItem(_variant_t((long)(cnt)));
			if(lpDis)
			{
				sheet.AttachDispatch(lpDis, TRUE);
				m_Sheet.Move(vtMissing, _variant_t(sheet));
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CExcelUtil::ActiveSheet(int iIndex)
{
	if(1 > iIndex)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min sheet number is 1!"));
		return FALSE;
	}
	if(GetSheetCount() < iIndex)
	{
		//�����sheet����������sheet��
		return FALSE;
	}

	LPDISPATCH lpDis = NULL;
	m_Range.ReleaseDispatch();
	m_Sheet.ReleaseDispatch();
	lpDis = m_Sheets.GetItem(_variant_t((long)iIndex));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		m_Sheet.Activate();
		return TRUE;
	}
	return FALSE;
}

BOOL CExcelUtil::ActiveSheet(CString strSheetName)
{
	if(strSheetName.IsEmpty())
	{
		return FALSE;
	}

	m_Range.ReleaseDispatch();
	m_Sheet.ReleaseDispatch();
	LPDISPATCH lpDis = NULL;
	//�¼���Sheet
	lpDis = m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString()));
	if(lpDis)
	{
		m_Sheet.AttachDispatch(lpDis, TRUE);
		m_Sheet.Activate();
	}
	return TRUE;
}

CString CExcelUtil::GetSheetName(int iIndex)
{
    if(1 > iIndex)
    {
        //��������ȷ������FALSE
        AfxMessageBox(_T("Min sheet number is 1!"));
        return _T("");
    }
    if(GetSheetCount() < iIndex)
    {
        //�����sheet����������sheet��
        return _T("");
    }

    _Worksheet sheet;
    sheet.AttachDispatch(m_Sheets.GetItem(_variant_t((long)iIndex)), TRUE);
    CString strName = sheet.GetName();
    sheet.ReleaseDispatch();
    return strName;
}

int CExcelUtil::GetSheetIndex(CString strSheetName)
{
	if(strSheetName.IsEmpty())
		return 0;

	_Worksheet sheet;
	sheet.AttachDispatch(m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString())), TRUE);
	int index = sheet.GetIndex();
	sheet.ReleaseDispatch();
	return index;
}

BOOL CExcelUtil::FindSheet(CString strSheetName)
{
    if(strSheetName.IsEmpty())
    {
        return FALSE;
    }

    m_Range.ReleaseDispatch();
    m_Sheet.ReleaseDispatch();
    LPDISPATCH lpDis = NULL;
    //�¼���Sheet
    lpDis = m_Sheets.GetItem(_variant_t(strSheetName.AllocSysString()));
    if(lpDis)
    {
        return TRUE;
    }
    return FALSE;
}

int CExcelUtil::GetSheetCount()
{
    return m_Sheets.GetCount();
}

int CExcelUtil::GetRowCount()
{
	_Range range;
	_Range usedRange;
	usedRange.AttachDispatch(m_Sheet.GetUsedRange(), TRUE);
	range.AttachDispatch(usedRange.GetRows(), TRUE);
	int iCount = range.GetCount();
	usedRange.ReleaseDispatch();
	range.ReleaseDispatch();
	return iCount;
}

int CExcelUtil::GetColCount()
{
	_Range range;
	_Range usedRange;
	usedRange.AttachDispatch(m_Sheet.GetUsedRange(), TRUE);
	range.AttachDispatch(usedRange.GetColumns(), TRUE);
	int iCount = range.GetCount();
	usedRange.ReleaseDispatch();
	range.ReleaseDispatch();
	return iCount;
}

void CExcelUtil::InsertRow(int iRow)
{
	_Range rgBefore, rgAfter;
	m_Range.AttachDispatch(m_Range.GetCells(), TRUE);
	rgBefore.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow), _variant_t((long)1)).pdispVal, TRUE);  
	rgBefore.AttachDispatch(rgBefore.GetEntireRow(), TRUE);                                                      //����/���Ʋ��뵥Ԫ��ĸ�ʽ  
	rgAfter.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow), _variant_t((long)1)).pdispVal, TRUE);  
	rgAfter.AttachDispatch(rgAfter.GetEntireRow(), TRUE);//((short)(m_iRow))                                     //����/���Ʋ��뵥Ԫ��ĸ�ʽ  
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);  
	rgAfter.Copy(covOptional);  
	rgBefore.Insert(_variant_t((long)iRow));
}

void CExcelUtil::DeleteRow(int iRow)
{
	m_Range.AttachDispatch(m_Sheet.GetRows(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),vtMissing).pdispVal,true);
	m_Range.Delete(_variant_t((long)iRow));
}

void CExcelUtil::SetRowHeight(int iRow, double height)
{
	m_Range.AttachDispatch(m_Sheet.GetRows(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),vtMissing).pdispVal,true);
	m_Range.SetRowHeight(_variant_t((long)height));
}

void CExcelUtil::DeleteColumn(int iFromCol, int iEndCol)
{
	m_Range.AttachDispatch(m_Sheet.GetColumns(),true);
	if(iEndCol > iFromCol)
	{
		for(int i=iFromCol; i<=iEndCol; i++)
		{
			m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)i),vtMissing).pdispVal,true);
			m_Range.Delete(vtMissing);
		}
	}
	else
	{
		m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iFromCol),vtMissing).pdispVal,true);
		m_Range.Delete(vtMissing);
	}
}

void CExcelUtil::SetColumnWidth(long lWidth, int iFromCol, int iEndCol)
{
	m_Range.AttachDispatch(m_Sheet.GetColumns(),true);
	if(iEndCol > iFromCol)
	{
		for(int i=iFromCol; i<=iEndCol; i++)
		{
			m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)i),vtMissing).pdispVal,true);
			m_Range.SetColumnWidth(_variant_t((long)lWidth));
		}
	}
	else
	{
		m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iFromCol),vtMissing).pdispVal,true);
		m_Range.SetColumnWidth(_variant_t((long)lWidth));
	}
}

void CExcelUtil::SetCell(int iValue, int iRow, int iCol)
{
    _Range range;
    range.AttachDispatch(m_Range.GetCells(), TRUE);
    COleVariant vValue;
    vValue.vt = VT_INT;
    vValue.intVal = iValue;
    range.SetItem(_variant_t((long)iRow), _variant_t((long)iCol), vValue);
}

void CExcelUtil::SetCell(double fValue, int iRow, int iCol)
{
    _Range range;
    range.AttachDispatch(m_Range.GetCells(), TRUE);
    range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), _variant_t(fValue));
}

void CExcelUtil::SetCell(CString strValue, int iRow, int iCol)
{
    _Range range;
    range.AttachDispatch(m_Range.GetCells(), TRUE);
    range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), _variant_t(strValue));
}

void CExcelUtil::SetCell(SYSTEMTIME st, int iRow, int iCol)
{
    _Range range;
    range.AttachDispatch(m_Range.GetCells(), TRUE);
    COleVariant vResult;
    SystemTimeToVariantTime(&st, &vResult.date);
    vResult.vt = VT_DATE;
    range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), vResult);
}

void CExcelUtil::SetCell(CTime dt, int iRow, int iCol)
{
	_Range range;
	range.AttachDispatch(m_Range.GetCells(), TRUE);
	COleVariant vResult;
	SYSTEMTIME st;
	dt.GetAsSystemTime(st);
	SystemTimeToVariantTime(&st, &vResult.date);
	vResult.vt = VT_DATE;
	range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), vResult);
}

void CExcelUtil::SetCell(COleDateTime odt, int iRow, int iCol)
{
	_Range range;
	range.AttachDispatch(m_Range.GetCells(), TRUE);
	COleVariant vResult;
	SYSTEMTIME st;
	odt.GetAsSystemTime(st);
	SystemTimeToVariantTime(&st, &vResult.date);
	vResult.vt = VT_DATE;
	range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), vResult);
}

void CExcelUtil::SetCell(VARIANT vt, int iRow, int iCol)
{
	_Range range;
	range.AttachDispatch(m_Range.GetCells(), TRUE);
	range.SetItem(_variant_t((long)iRow),_variant_t((long)iCol), _variant_t(vt));
}

int CExcelUtil::GetCellInt(int iRow, int iCol)
{
    int iValue = 0;
    if(1 > iRow || 1 > iCol)
    {
        //��������ȷ������FALSE
        AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
        return iValue;
    }
    
    if(GetRowCount() < iRow || GetColCount() < iCol)
    {
        //����������������������ߴ������������������
        return iValue;
    }

    _Range range;
    range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
    COleVariant vResult = range.GetValue(m_covOptional); //��Ҫ��֤�Ƿ���ȷ
    iValue = vResult.intVal;

    range.ReleaseDispatch();
    
    return iValue;
}

long CExcelUtil::GetCellLong(int iRow, int iCol)
{
	long lValue = 0;
	if(1 > iRow || 1 > iCol)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
		return lValue;
	}

	if(GetRowCount() < iRow || GetColCount() < iCol)
	{
		//����������������������ߴ������������������
		return lValue;
	}

	_Range range;
	range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
	COleVariant vResult = range.GetValue(m_covOptional); //��Ҫ��֤�Ƿ���ȷ
	lValue = vResult.lVal;

	range.ReleaseDispatch();

	return lValue;
}

BOOL CExcelUtil::GetCellBool(int iRow, int iCol)
{
	BOOL bValue = 0;
	if(1 > iRow || 1 > iCol)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
		return bValue;
	}

	if(GetRowCount() < iRow || GetColCount() < iCol)
	{
		//����������������������ߴ������������������
		return bValue;
	}

	_Range range;
	range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
	COleVariant vResult = range.GetValue(m_covOptional); //��Ҫ��֤�Ƿ���ȷ
	bValue = vResult.boolVal;

	range.ReleaseDispatch();

	return bValue;
}

double CExcelUtil::GetCellDouble(int iRow, int iCol)
{
    double fValue = 0;
    if(1 > iRow || 1 > iCol)
    {
        //��������ȷ������FALSE
        AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
        return fValue;
    }
    
    if(GetRowCount() < iRow || GetColCount() < iCol)
    {
        //����������������������ߴ������������������
        return fValue;
    }
    
    _Range range;
    range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
    COleVariant vResult = range.GetValue(m_covOptional);
	fValue = vResult.dblVal;
    
    range.ReleaseDispatch();
    
    return fValue;
}

CString CExcelUtil::GetCellString(int iRow, int iCol)
{
    if(1 > iRow || 1 > iCol)
    {
        //��������ȷ������FALSE
        AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
        return _T("");
    }

    if(GetRowCount() < iRow || GetColCount() < iCol)
    {
        //����������������������ߴ������������������
        return _T("");
    }

    _Range range;
    range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow),COleVariant((long)iCol)).pdispVal, TRUE);
    //long RangeValueDataType = 1;
    COleVariant vResult = range.GetValue(m_covOptional);
    CString strValue;
    switch(vResult.vt)
    {
    case VT_BSTR:  //�ַ���
        strValue = vResult.bstrVal;
        break;
    case VT_INT:   //��������
        strValue.Format(_T("%d"), vResult.pintVal);
        break;
    case VT_R8:    //8�ֽڵ����� 
        strValue.Format(_T("%.3f"), vResult.dblVal);//С���������λ
        break;
    case VT_DATE:  //ʱ���ʽ
        SYSTEMTIME st;
        VariantTimeToSystemTime(vResult.date, &st);
        if(0 == st.wHour && 0 == st.wMinute && 0 == st.wSecond)
        {
            strValue.Format(_T("%d-%d-%d"), st.wYear, st.wMonth, st.wDay);
        }
        else
        {
            strValue.Format(_T("%d-%d-%d %d:%d:%d"), st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        }
        break;
    case VT_EMPTY: //��Ԫ���ǿյ�
        strValue = _T("");
        break;
    case VT_NULL:  //��Ԫ����NULL
        strValue = _T("");
        break;
    default:
        strValue = vResult.bstrVal;
        break;
    }
    
    range.ReleaseDispatch();
    
    return strValue;
}

SYSTEMTIME CExcelUtil::GetSystemTime(int iRow, int iCol)
{
	if(1 > iRow || 1 > iCol)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
		return SYSTEMTIME();
	}

	if(GetRowCount() < iRow || GetColCount() < iCol)
	{
		//����������������������ߴ������������������
		return SYSTEMTIME();
	}

	_Range range;
	SYSTEMTIME st;
	range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
	COleVariant vResult = range.GetValue(m_covOptional);
	if(vResult.vt == VT_DATE)
	{
		VariantTimeToSystemTime(vResult.date, &st);
		range.ReleaseDispatch();

		return st;
	}

	CTime::GetCurrentTime().GetAsSystemTime(st);
	return st;
}

CTime CExcelUtil::GetCellDateTime(int iRow, int iCol)
{
	if(1 > iRow || 1 > iCol)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
		return CTime();
	}

	if(GetRowCount() < iRow || GetColCount() < iCol)
	{
		//����������������������ߴ������������������
		return CTime();
	}

	_Range range;
	range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
	COleVariant vResult = range.GetValue(m_covOptional);
	if(vResult.vt == VT_DATE)
	{
		SYSTEMTIME st;
		VariantTimeToSystemTime(vResult.date, &st);
		range.ReleaseDispatch();

		return CTime(st);
	}

	return CTime::GetCurrentTime();
}

COleDateTime CExcelUtil::GetCellOleDateTime(int iRow, int iCol)
{
	if(1 > iRow || 1 > iCol)
	{
		//��������ȷ������FALSE
		AfxMessageBox(_T("Min row number is 1, Min column number is also 1!"));
		return COleDateTime();
	}

	if(GetRowCount() < iRow || GetColCount() < iCol)
	{
		//����������������������ߴ������������������
		return COleDateTime();
	}

	_Range range;
	range.AttachDispatch(m_Range.GetItem(COleVariant((long)iRow), COleVariant((long)iCol)).pdispVal, TRUE);
	COleVariant vResult = range.GetValue(m_covOptional);
	if(vResult.vt == VT_DATE)
	{
		SYSTEMTIME st;
		VariantTimeToSystemTime(vResult.date, &st);
		range.ReleaseDispatch();

		return COleDateTime(st);
	}

	return COleDateTime::GetCurrentTime();
}

VARIANT CExcelUtil::GetCell(int iRow, int iCol)
{
    _Range range = m_Range.GetItem(_variant_t((long)iRow),_variant_t((long)iCol)).pdispVal;
    return range.GetText();
}

BOOL CExcelUtil::FindPathEndChar(CString strFilePath)
{
    int nLen = strFilePath.GetLength();
    if(strFilePath.GetAt(nLen - 1) == '\\')
    {
        return TRUE;
    }
    return FALSE;
}

void CExcelUtil::PrintPreview(BOOL bPrintPreview)
{
	m_Book.PrintPreview(_variant_t(bPrintPreview)); 
}

void CExcelUtil::RunMicro(CString macro)
{
	m_ExcelApp.Run(_variant_t(macro),vtMissing,vtMissing,vtMissing, 
		vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing, 
		vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing, 
		vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing, 
		vtMissing,vtMissing,vtMissing,vtMissing,vtMissing,vtMissing);
}

void CExcelUtil::SetCellAlignment(int iRow, int iCol, ENUM_CELL_ALIGNMENT eHorizon, ENUM_CELL_ALIGNMENT eVertical)
{
	m_Range.AttachDispatch(m_Sheet.GetCells(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),_variant_t((long)iCol)).pdispVal,true);

	switch (eHorizon)
	{
	case HORIZON_MIDDLE:
		m_Range.SetHorizontalAlignment(_variant_t((long)-4108));
		break;
	case HORIZON_LEFT:
		m_Range.SetHorizontalAlignment(_variant_t((long)-4131));
		break;
	case HORIZON_RIGHT:
		m_Range.SetHorizontalAlignment(_variant_t((long)-4152));
		break;
	default:
		break;
	}

	switch (eVertical)
	{
	case VERTICAL_UP:
		m_Range.SetVerticalAlignment(_variant_t((long)-4160));
		break;
	case VERTICAL_MIDDLE:
		m_Range.SetVerticalAlignment(_variant_t((long)-4108));
		break;
	case VERTICAL_DOWN:
		m_Range.SetVerticalAlignment(_variant_t((long)-4107));
		break;
	default:
		break;
	}
}

void CExcelUtil::SetCellFont(int iRow, int iCol, _Font &font)
{
	m_Range.AttachDispatch(m_Sheet.GetCells(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),_variant_t((long)iCol)).pdispVal,true);
	font.AttachDispatch(m_Range.GetFont());
}

void CExcelUtil::SetCellFontColor(int iRow, int iCol, ENUM_CELL_FONTCOLOR eFontColor)
{
	_Font Cfont;
	m_Range.AttachDispatch(m_Sheet.GetCells(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),_variant_t((long)iCol)).pdispVal,true);
	Cfont.AttachDispatch(m_Range.GetFont());
	switch (eFontColor)
	{
	case FONT_NULL:
		break;
	case FONT_RED:
		Cfont.SetColor(COleVariant((long)0x0000FF));		// �����̡���
		break;
	case FONT_BLUE:
		Cfont.SetColor(COleVariant((long)0xFF0000));
		break;
	case FONT_GREEN:
		Cfont.SetColor(COleVariant((long)0x00FF00));
		break;
	default:
		break;
	}
}

void CExcelUtil::MergeCell(int iRow, int iCol, int row_count, int col_count)
{
	m_Range.AttachDispatch(m_Sheet.GetCells(),true);
	m_Range.AttachDispatch(m_Range.GetItem(_variant_t((long)iRow),_variant_t((long)iCol)).pdispVal,true);
	m_Range.AttachDispatch(m_Range.GetResize(_variant_t((long)row_count),_variant_t((long)col_count)));
	m_Range.Merge(COleVariant((long)0));
}

void CExcelUtil::Paste(int iRow, int iCol)
{
	m_Range.AttachDispatch(m_Sheet.GetCells(),true);
	m_Range.AttachDispatch(m_Range.GetItem (COleVariant((long)iRow),COleVariant((long)iCol)).pdispVal, true);
	m_Range.Select();
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND,   VT_ERROR);   
	m_Sheet.Paste(covOptional, covOptional);
	m_Range.AttachDispatch(m_ExcelApp.GetSelection());
	m_Range.AttachDispatch(m_Range.GetEntireColumn(), true);
	m_Range.AutoFit();
	m_ExcelApp.SetVisible(TRUE);
}

BOOL CExcelUtil::ConnectTxt(CString strFilePath, int iRow, int iCol)
{
	CFileFind FileFind;
	if(FileFind.FindFile(strFilePath) == FALSE)
		return FALSE;

	m_Querys.AttachDispatch(m_Sheet.GetQueryTables());
	CString ConnetionSet = _T("TEXT;")+strFilePath;
	COleVariant covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);
	m_Query.AttachDispatch(m_Querys.Add(COleVariant(ConnetionSet), m_Range.GetItem (COleVariant((long)iRow),COleVariant((long)iCol)).pdispVal, covOptional));
	m_Query.Refresh(COleVariant(long(0)));
	m_Query.ReleaseDispatch();

	return TRUE;
}