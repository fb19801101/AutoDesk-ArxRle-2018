//
//  MODULE: Ado.cpp
//
//	AUTHOR: Carlos Antollini 
//
//  mailto: cantollini@hotmail.com
//
//	Date: 07/25/2002
//
//	Version 2.04
// 
#include "stdafx.h"
#include "ado.h"
#include <regex>

#define ChunkSize 512


CString IntToStr(int nVal)
{
	CString strRet;
	strRet.Format(_T("%d"),nVal);
	return strRet;
}

CString LongToStr(long lVal)
{
	CString strRet;
	strRet.Format(_T("%ld"),lVal);
	return strRet;
}

CString ULongToStr(unsigned long ulVal)
{
	CString strRet;
	strRet.Format(_T("%lu"),ulVal);
	return strRet;
}

CString DblToStr(double dblVal, int ndigits)
{
	CString strRet,f;
	f.Format(_T("%d"),ndigits);
	f=_T("%.")+f+_T("f");
	strRet.Format(f,dblVal);
	strRet.Format(_T("%.*f"), ndigits, dblVal);
	return strRet;
}

CString DblToStr(float fltVal)
{
	CString strRet;
	strRet.Format(_T("%.3f"),fltVal);
	return strRet;
}



///////////////////////////////////////////////////////
//
// CADOData Class
//
CADOData::CADOData()
{
	row1 = 0;
	row2 = 0;
	rows = 0;
	col1 = 0;
	col2 = 0;
	cols = 0;
	vals[0] = NULL;
	vals[1] = NULL;
	vals[2] = NULL;
}

CADOData::CADOData(const long r1, const long r2, const int c1, const int c2)
{
	row1 = r1;
	row2 = r2;
	col1 = c1;
	col2 = c2;
	rows = row2-row1+1;
	cols = col2-col1+1;
	vals[0] = NULL;
	vals[1] = NULL;
	vals[2] = NULL;
	_variant_t** val = new _variant_t*[rows];
	for(int i=0;i<rows;i++) val[i] = new _variant_t[cols];
	vals[0] = val;

	_variant_t* sum = new _variant_t[cols]();
	vals[1] = sum;
}

CADOData::CADOData(_variant_t**& src, const long r1, const long r2, const int c1, const int c2)
{
	if(src == NULL) return;
	row1 = r1;
	row2 = r2;
	col1 = c1;
	col2 = c2;
	rows = row2-row1+1;
	cols = col2-col1+1;
	vals[0] = src;
	vals[1] = NULL;
	vals[2] = NULL;
}

CADOData::CADOData(_variant_t**& src, const long r1, const long r2, const int c1, const int c2, _variant_t*& sum)
{
	if(src == NULL) return;
	row1 = r1;
	row2 = r2;
	col1 = c1;
	col2 = c2;
	rows = row2-row1+1;
	cols = col2-col1+1;
	vals[0] = src;
	vals[1] = sum;
	vals[2] = NULL;
}

CADOData::CADOData(_variant_t*& src, const long r1, const int c1)
{
	if(src == NULL) return;
	row1 = r1;
	row2 = 0;
	col1 = c1;
	col2 = 0;
	rows = 1;
	cols = 1;
	vals[0] = NULL;
	vals[1] = NULL;
	vals[2] = src;
}

CADOData& CADOData::operator=(const CADOData& src)
{
	rows = src.rows;
	cols = src.cols;
	row1 = src.row1;
	row2 = src.row2;
	col1 = src.col1;
	col2 = src.col2;
	vals[0] = src.vals[0];
	vals[1] = src.vals[1];
	vals[2] = src.vals[2];
	return *this;
}

void CADOData::Release()
{
	if(rows > 0 && cols > 0 && vals[0] != NULL)
	{
		_variant_t** val = (_variant_t**)vals[0];
		for(int i=0;i<cols;i++) delete[] val[i];
		delete[] val;
	}

	if(rows > 0 && cols > 0 && vals[1] != NULL)
	{
		_variant_t* sum = (_variant_t*)vals[1];
		delete[] sum;
	}

	if(vals[2] != NULL) delete vals[2];

	row1 = 0;
	row2 = 0;
	rows = 0;
	col1 = 0;
	col2 = 0;
	cols = 0;
	vals[0] = NULL;
	vals[1] = NULL;
	vals[2] = NULL;
}

bool CADOData::IsNull()
{
	return vals == NULL ? true:false;
}



///////////////////////////////////////////////////////
//
// CADOConnection Class
//

CADOConnection::CADOConnection(_ConnectionPtr& con)
{
	::CoInitialize(NULL);

	m_pConnection = con;
	BSTR* str = 0;
	m_pConnection->get_ConnectionString(str);
	m_strConnection = (LPCSTR)str;
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_nRecordsAffected = 0;
}

CADOConnection::CADOConnection(CADOConnection& adoCon)
{
	::CoInitialize(NULL);

	m_pConnection = adoCon.GetConnection();
	BSTR* str = 0;
	m_pConnection->get_ConnectionString(str);
	m_strConnection = (LPCSTR)str;
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_nRecordsAffected = 0;
}

CADOConnection& CADOConnection::operator=(_ConnectionPtr& con)
{
	::CoInitialize(NULL);

	m_pConnection = con;
	BSTR* str = 0;
	m_pConnection->get_ConnectionString(str);
	m_strConnection = (LPCSTR)str;
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_nRecordsAffected = 0;

	return *this;
}

CADOConnection& CADOConnection::operator=(CADOConnection& adoCon)
{
	::CoInitialize(NULL);

	m_pConnection = adoCon.GetConnection();
	BSTR* str = 0;
	m_pConnection->get_ConnectionString(str);
	m_strConnection = (LPCSTR)str;
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_nRecordsAffected = 0;

	return *this;
}

DWORD CADOConnection::GetRecordCount(_RecordsetPtr pRs)
{
	DWORD numRows = 0;

	numRows = pRs->GetRecordCount();

	if(numRows == -1)
	{
		if(pRs->_EOF != VARIANT_TRUE)
			pRs->MoveFirst();

		while(pRs->_EOF != VARIANT_TRUE)
		{
			numRows++;
			pRs->MoveNext();
		}
		if(numRows > 0)
			pRs->MoveFirst();
	}
	return numRows;
}

BOOL CADOConnection::Open(CString strConnection, CString strUserID, CString strPassword,Enum_AdoConnectionOption enuOption)
{
	HRESULT hr = S_OK;

	if(IsOpen()) Close();

	if(strConnection.GetLength() > 0)
		m_strConnection = strConnection;

	ASSERT(!m_strConnection.IsEmpty());

	try
	{
		hr = m_pConnection->Open(_bstr_t(m_strConnection), _bstr_t(strUserID), _bstr_t(strPassword), enuOption);
		return hr == S_OK;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

int CADOConnection::Execute(CString strExec)
{
	ASSERT(m_pConnection != NULL);
	ASSERT(strExec.GetLength() > 0);
	_variant_t vRecords;

	m_nRecordsAffected = 0;

	try
	{
		strExec.TrimLeft();
		BOOL bIsSelect = strExec.Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0;

		if(bIsSelect)
		{
			m_pConnection->CursorLocation = adUseClient;
			_RecordsetPtr rst = m_pConnection->Execute(_bstr_t(strExec), &vRecords, adCmdText/*adExecuteNoRecords*/);
			m_nRecordsAffected = rst->GetRecordCount();
			rst->Close();
		}
		else
		{
			m_pConnection->CursorLocation = adUseClient;
			m_pConnection->Execute(_bstr_t(strExec), &vRecords, adCmdText/*adExecuteNoRecords*/);
			m_nRecordsAffected = vRecords.iVal;
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}

	return m_nRecordsAffected;
}

void CADOConnection::dump_com_error(_com_error &e)
{
	CString ErrorStr;

	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format(_T("CADOConnection Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription );
	m_strLastError = _T("Connection String = ") + GetConnectionString() + _T("\n") + ErrorStr;
	m_dwLastError = e.Error();
#ifdef _DEBUG
	AfxMessageBox( ErrorStr, MB_OK | MB_ICONERROR );
#endif	
}

BOOL CADOConnection::IsOpen()
{
	if(m_pConnection ) return m_pConnection->GetState() != adStateClosed;
	return FALSE;
}

void CADOConnection::Close()
{
	if(IsOpen()) m_pConnection->Close();
}



///////////////////////////////////////////////////////
//
// CADOCatalog Class
//

CADOCatalog::CADOCatalog(ADOX::_CatalogPtr& cat)
{
	::CoInitialize(NULL);

	m_pCatalog = cat;
	m_strCatalog = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
}

CADOCatalog::CADOCatalog(CADOCatalog& adoCat)
{
	::CoInitialize(NULL);

	m_pCatalog = adoCat.GetCatalog();
	m_strCatalog = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
}

CADOCatalog& CADOCatalog::operator=(ADOX::_CatalogPtr& cat)
{
	::CoInitialize(NULL);

	m_pCatalog = cat;
	m_strCatalog = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;

	return *this;
}

CADOCatalog& CADOCatalog::operator=(CADOCatalog& adoCat)
{
	::CoInitialize(NULL);

	m_pCatalog = adoCat.GetCatalog();
	m_strCatalog = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;

	return *this;
}

BOOL CADOCatalog::Create(CString strCatalog)
{
	HRESULT hr = S_OK;

	if(strCatalog.GetLength() > 0)
		m_strCatalog = strCatalog;

	ASSERT(!m_strCatalog.IsEmpty());

	try
	{
		hr = m_pCatalog->Create(_bstr_t(m_strCatalog));
		return hr == S_OK;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

void CADOCatalog::dump_com_error(_com_error &e)
{
	CString ErrorStr;

	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CADOCatalog Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription );
	m_strLastError = _T("CADOCatalog String = ") + GetCatalogString() + _T("\n") + ErrorStr;
	m_dwLastError = e.Error();
#ifdef _DEBUG
	AfxMessageBox( ErrorStr, MB_OK | MB_ICONERROR );
#endif	
}





///////////////////////////////////////////////////////
//
// CADODatabase Class
//

BOOL CADODatabase::OpenConnection()
{
	return m_adoConnection.Open(GetConString());
}

BOOL CADODatabase::CreateCatalog()
{
	return m_adoCatalog.Create(GetConString());
}

BOOL CADODatabase::Execute(CString strExec)
{
	return m_adoConnection.Execute(strExec);
}

void CADODatabase::CloseConnection()
{
	m_adoConnection.Close();
}

CString CADODatabase::GetConString() const
{
	CString strConString;
	switch (m_enuDataDriver)
	{
	case adoAccess:
		strConString.Format(_T("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=%s%s;Mode='ReadWrite';Persist Security Info='False';Jet OLEDB:Database Password=%s"), m_strDataPath, m_strDataBase, m_strPwd);
		break;
	case adoExcel:
		strConString.Format(_T("Provider=Microsoft.ACE.OLEDB.12.0;Extended Properties='Excel 8.0;IMEX=1;HDR=YES';Data Source=%s%s"), m_strDataPath, m_strDataBase);
		break;
	case adoText:
		strConString.Format(_T("Provider=Microsoft.JET.OLEDB.4.0;Extended Properties='text;IMEX=1;HDR=NO;FMT=Delimited;';Data Source=%s%s"), m_strDataPath, m_strDataBase);
		break;
	case adoMYSQL:
		strConString.Format(_T("Provider=SQLOLEDB;Security Info=False;Integrated Security=SSPI;Server=%s;DataSource=%s;Initial Catolog=%s"), m_strServer, m_strDataPath, m_strDataBase);
		break;
	case adoMSSQL:
		if(m_strServer == _T("."))
			strConString.Format(_T("Driver={SQL Server};Server=.;DataSource=%s;Initial Catolog=%s"), m_strDataPath, m_strDataBase);
		else
			strConString.Format(_T("Driver={SQL Server};Server=%s;DataSource=%s;Initial Catolog=%s;uid=%s;pwd=%s"), m_strServer, m_strDataPath, m_strDataBase,m_strUId,m_strPwd);
		break;
	}
	return strConString;
}

void CADODatabase::SetFieldProperty(CString tbl, int col1, int col2)
{
	//0 Autoincrement �Զ����
	//1 Default Ĭ��ֵ
	//2 Description
	//3 Nullable �����ֶ�
	//4 Fixed Length
	//5 Seed
	//6 Increment
	//7 Jet OLEDB:Column Validation Text ��Ч���ı�
	//8 Jet OLEDB:Column Validation Rule ��Ч�Թ���
	//9 Jet OLEDB:IISAM Not Last Column
	//10 Jet OLEDB: AutoGenerate
	//11 Jet OLEDB:One BLOB per Page
	//12 Jet OLEDB:Compressed UNICODE Strings
	//13 Jet OLEDB:Allow Zero Length �������ַ���
	//14 Jet OLEDB: Hyperlink ��������
	ADOX::TablesPtr tbs;
	ADOX::_TablePtr tb;
	ADOX::ColumnsPtr cols;
	tbs = m_adoCatalog.GetCatalog()->GetTables();
	tb = tbs->GetItem(_bstr_t(tbl));
	cols = tb->GetColumns();
	int cs = cols->GetCount();
	for(int i=0; i<cs;i++)
	{
		ADOX::_ColumnPtr col = cols->GetItem(i);
		if(i>=col1 && i<=col2)
		{
			ADOX::PropertiesPtr pros = col->GetProperties();
			ADOX::PropertyPtr pro = pros->GetItem(_bstr_t(_T("Default")));
			pro->GetValue() = 0;
		}
	}
}

CString CADODatabase::GetFields(CString tbl, int col1, int col2)
{
	CString sql;
	sql.Format(_T("select * from %s"),tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql, CADORecordset::adoRstStoredProc);

	CString fids;
	long fs = rst.GetFieldCount();
	for(int i=0; i<fs;i++)
	{
		Stru_AdoFieldInfo inf;
		rst.GetFieldInfo(i, &inf);
		if(i >= col1 && i <= col2)
		{
			CString fid;
			fid.Format(_T("[%s], "),inf.m_strName);
			fids += fid;
		}
	}
	rst.Close();

	return fids.Mid(0, fids.GetLength() - 2);
}

int CADODatabase::GetFields(CString tbl, int col1, int col2, CString*& fids)
{
	CString sql;
	sql.Format(_T("select * from %s"),tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);

	long fs = rst.GetFieldCount();
	int cs = 0;
	for(int i=0; i<fs;i++)
	{
		Stru_AdoFieldInfo inf;
		rst.GetFieldInfo(i, &inf);
		if(i>= col1 && i <= col2) cs++;
	}
	fids = new CString[cs];
	cs = 0;
	for(int i=0; i<fs;i++)
	{
		Stru_AdoFieldInfo inf;
		rst.GetFieldInfo(i, &inf);
		if(i>= col1 && i <= col2)
		{
			CString fid;
			fid.Format(_T("%s"),inf.m_strName);
			fids[cs++] = fid;
		}
	}
	rst.Close();

	return cs;
}

CString CADODatabase::_GetFields(CString tbl, int idx, int* cols)
{
	CString sql;
	sql.Format(_T("select * from %s"),tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);

	CString fids;
	long fs = rst.GetFieldCount();
	int k = 0;
	for(int i=0; i<fs;i++)
	{
		Stru_AdoFieldInfo inf;
		rst.GetFieldInfo(i, &inf);

		if(k == idx) break;
		int a = cols[k];
		if(i == cols[k])
		{
			CString fid;
			fid.Format(_T("[%s], "),inf.m_strName);
			fids += fid;
		}
	}
	rst.Close();

	return fids.Mid(0, fids.GetLength() - 2);
}

void CADODatabase::_GetFields(CString tbl, int idx, int* cols, CString*& fids)
{
	CString sql;
	sql.Format(_T("select * from %s"),tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);

	long fs = rst.GetFieldCount();
	fids = new CString[idx];
	int cs = 0;
	int k = 0;
	for(int i=0; i<fs;i++)
	{
		Stru_AdoFieldInfo inf;
		rst.GetFieldInfo(i, &inf);
		if(k == idx) break;
		if(i == cols[k])
		{
			CString fid;
			fid.Format(_T("%s"),inf.m_strName);
			fids[k++] = fid;
		}
	}
	rst.Close();
}

void CADODatabase::SetProceduresSql(CString tbl, CString sql)
{
	if(sql.GetLength() == 0) return;
	ASSERT(sql);

	ADOX::ProceduresPtr pros = m_adoCatalog.GetCatalog()->GetProcedures();
	ADOX::ProcedurePtr pro = pros->GetItem(_bstr_t(tbl));
	_CommandPtr cmd = pro->GetCommand();
	cmd->CommandText = (LPCTSTR)sql;
	pro->GetCommand() = cmd;
	pros.Release();
	pro.Release();
	cmd.Release();
	pros = pro = cmd =NULL;
}

void CADODatabase::SetViewSql(CString tbl, CString sql)
{
	if(sql.GetLength() == 0) return;
	ASSERT(sql);

	ADOX::ViewsPtr views = m_adoCatalog.GetCatalog()->GetViews();
	ADOX::ViewPtr view = views->GetItem(_bstr_t(tbl));
	_CommandPtr cmd = view->GetCommand();
	cmd->CommandText = (LPCTSTR)sql;
	view->GetCommand() = cmd;
	views.Release();
	view.Release();
	cmd.Release();
	views = view = cmd =NULL;
}

void CADODatabase::SetQuery(CString tbl, char* s1, char* s2)
{
	ADOX::ViewsPtr views = m_adoCatalog.GetCatalog()->GetViews();
	ADOX::ViewPtr view = views->GetItem(_bstr_t(tbl));
	_CommandPtr cmd = view->GetCommand();
	std::string sql = cmd->CommandText;
	std::regex rx(s1);   
	std::string fmt(s2);   
	std::string buf = std::regex_replace(sql, rx, fmt);

	cmd->CommandText = _bstr_t(buf.c_str());
	view->GetCommand() = cmd;
	views.Release();
	view.Release();
	cmd.Release();
	views = view = cmd =NULL;
}

long CADODatabase::GetRecordCount(CString tbl)
{
	CString sql;
	sql.Format(_T("select * from %s  order by ID"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	long rs = rst.GetRecordCount();
	rst.Close();
	return rs;
}

long CADODatabase::AddRecord(CString tbl, CString fids, CString vals)
{
	CString sql;
	sql.Format(_T("insert into %s (%s) values (%s)"), tbl, fids, vals);
	Execute(sql);

	sql.Format(_T("select * from  %s order by ID"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	long id = rst.GetRecordCount();
	rst.Close();
	return id;
}

long CADODatabase::AddRecord(CString tbl, int idxs, CString*& fids, CADOData& data)
{
	CString sql;
	sql.Format(_T("select * from  %s order by ID"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	long id = rst.GetRecordCount()+1;

	rst.AddNew();
	rst.SetFieldValue(_T("ID"),id);

	_variant_t* val = (_variant_t*)data.vals[0];
	for(int i=0;i<idxs;i++) rst.SetFieldValue(fids[i],val[i]);

	rst.Update();
	rst.Close();
	return id;
}

long CADODatabase::AddRecord(CString tbl, long rows, int idxs, CString*& fids, CADOData& data)
{
	CString sql;
	sql.Format(_T("select * from  %s order by ID"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	long id1 = rst.GetRecordCount()+1;
	long id2 = id1+rows-1;

	long rs = 0;

	_variant_t** vals = (_variant_t**)data.vals[0];
	for(long i=id1; i<=id2; i++)
	{
		rst.AddNew();
		rst.SetFieldValue(_T("ID"),i);
		_variant_t* val = vals[rs++];
		for(int j=0;j<idxs;j++) rst.SetFieldValue(fids[j],val[j]);
		rst.Update();
	}
	
	rst.Close();
	return id1;
}

void CADODatabase::SetRecord(CString tbl, long id, CString fidvals)
{
	CString sql;
	sql.Format(_T("update %s set %s where ID = %d"), tbl, fidvals, id);
	Execute(sql);
}

void CADODatabase::SetRecord(CString tbl, long id, int idxs, CString*& fids, CADOData& data)
{
	CString sql;
	sql.Format(_T("select * from %s where ID = %d"), tbl, id);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	rst.Edit();

	_variant_t* val = (_variant_t*)data.vals[0];
	for(int i=0;i<idxs;i++) rst.SetFieldValue(fids[i],val[i]);
	
	rst.Update();
	rst.Close();
}

void CADODatabase::SetRecord(CString tbl, long id1, long id2, int idxs, CString*& fids, CADOData& data)
{
	CString sql;
	sql.Format(_T("select * from %s where ID between %d and %d order by ID"), tbl, id1, id2);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);

	int rs = 0;

	_variant_t** vals = (_variant_t**)data.vals[0];
	while (!rst.IsEOF())
	{
		rst.Edit();
		_variant_t* val = vals[rs++];
		for(int i=0;i<idxs;i++)
		{
			rst.SetFieldValue(fids[i],val[i]);
		}
		rst.Update();
		rst.MoveNext();
	}

	rst.Close();
}

void CADODatabase::ReSetID(CString tbl)
{
	CString sql;
	sql.Format(_T("select ID from %s order by ID"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);

	unsigned long id = 1;
	while (!rst.IsEOF())
	{
		rst.Edit();
		rst.SetFieldValue(0,id++);
		rst.Update();
		rst.MoveNext();
	}

	rst.Close();
}

void CADODatabase::GetRecord(CADOData& data, CString tbl, long id, CString fids)
{
	CString sql;
	sql.Format(_T("select %s from %s where ID = %d"), fids, tbl, id);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	int cs = rst.GetFieldCount();
	if(cs > 0)
	{
		_variant_t* val = new _variant_t[cs];
		for(int i=0;i<cs;i++) rst.GetFieldValue(i,val[i]);
		data.vals[0] = val;
	}

	rst.Close();
}

void CADODatabase::GetRecord(CADOData& data, CString tbl, long id1, long id2, CString fids)
{
	CString sql;
	sql.Format(_T("select %s from %s where ID between %d and %d order by ID"), fids, tbl, id1, id2);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	long rs = rst.GetRecordCount();
	int cs = rst.GetFieldCount();
	if(rs*cs > 0)
	{
		_variant_t** val = new _variant_t*[rs];
		for(int i=0;i<rs;i++)
		{
			val[i] = new _variant_t[cs];
			for(int j=0;j<cs;j++) rst.GetFieldValue(j,val[i][j]);
			rst.MoveNext();
		}
		data.vals[0] = val;
	}
	rst.Close();
}

void CADODatabase::GetRecord(CADORecordset& data, CString tbl, CString fid, CADOData& vals)
{
	CString sql;
	_variant_t* val = (_variant_t*)vals.vals[0];
	sql.Format(_T("select * from %s where %s = '%s'"), tbl, fid, val[0]);

	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	rst.Clone(data);
	rst.Close();
}

void CADODatabase::_GetRecord(CADOData& data, CString tbl, long id1, long id2, CString fids)
{
	CString sql;
	sql.Format(_T("select %s from %s where ID between ? and ? order by ID"), fids, tbl);
	CADOCommand cmd(m_adoConnection,sql);
	cmd.AddParameter(_T("@id1"), adInteger, adParamInput, 4, id1);
	cmd.AddParameter(_T("@id2"), adInteger, adParamInput, 4, id2);
	CADORecordset rst(m_adoConnection);
	rst.Execute(cmd);
	long rs = rst.GetRecordCount();
	int cs = rst.GetFieldCount();
	if(rs*cs > 0)
	{
		_variant_t** val = new _variant_t*[rs];
		for(int i=0;i<rs;i++)
		{
			val[i] = new _variant_t[cs];
			for(int j=0;j<cs;j++) rst.GetFieldValue(j,val[i][j]);
			rst.MoveNext();
		}
		data.vals[0] = val;
	}
	rst.Close();
}

void CADODatabase::SumRecord(CADOData& data, CString tbl, int idx, CString*& fids)
{
	CString sql,str;
	for(int i=0; i<idx; i++)
	{
		CString s;
		s.Format(_T("sum([%s]), "),fids[i]);
		str += s;
	}
	str = str.Mid(0, str.GetLength() - 2);
	sql.Format(_T("select %s from %s"), str, tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	int cs = rst.GetFieldCount();
	if(cs > 0)
	{
		_variant_t* val = new _variant_t[cs];
		for(int i=0;i<cs;i++) rst.GetFieldValue(i,val[i]);
		data.vals[1] = val;
	}
	rst.Close();
}

void CADODatabase::FindRecord(CADOData& data, CString tbl, CString strFind, int nSearchDirection)
{
	ASSERT(!strFind.IsEmpty());

	CString sql;
	sql.Format(_T("select * from %s"), tbl);
	CADORecordset rst(m_adoConnection);
	rst.Open(sql,CADORecordset::adoRstStoredProc);
	CString fid = GetFields(tbl,data.col1,data.col1);
	strFind.Format(_T("%s=%s"), fid,strFind);

	if(rst.Find(strFind, nSearchDirection))
	{
		rst.GetFieldValue(0,data.row1);
		_variant_t val;
		rst.GetFieldValue(data.col2,val);
		data.vals[2] = &val;
	}
	rst.Close();
}

void CADODatabase::DelRecord(CString tbl, long id)
{
	CString sql;
	sql.Format(_T("delete from %s where ID = %d"), tbl, id);
	Execute(sql);
}

void CADODatabase::DelRecord(CString tbl, long id1, long id2)
{
	CString sql;
	sql.Format(_T("delete from %s where ID between %d and %d"), tbl, id1, id2);
	Execute(sql);
}



///////////////////////////////////////////////////////
//
// CADORecordset Class
//

CADORecordset::CADORecordset(_ConnectionPtr& pConnection)
{
	m_pRecordset = NULL;
	m_strQuery = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_pRecBinding = NULL;
	m_pRecordset.CreateInstance(__uuidof(Recordset));
	m_pRecordset->PutActiveConnection(_variant_t((IDispatch*)pConnection));
	m_pRecordset->CursorType = adOpenKeyset;
	m_pRecordset->LockType = adLockOptimistic;
	m_pRecordset->CursorLocation = adUseClient;
	m_nEditStatus = adoRstNone;
	m_nSearchDirection = adoRstForward;
}

CADORecordset::CADORecordset(CADOConnection& adoConnection)
{
	m_pRecordset = NULL;
	m_strQuery = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_pRecBinding = NULL;
	m_pRecordset.CreateInstance(__uuidof(Recordset));
	m_pRecordset->PutActiveConnection(_variant_t((IDispatch*)adoConnection.GetConnection()));
	m_pRecordset->CursorType = adOpenKeyset;
	m_pRecordset->LockType = adLockOptimistic;
	m_pRecordset->CursorLocation = adUseClient;
	m_nEditStatus = adoRstNone;
	m_nSearchDirection = adoRstForward;
}

CADORecordset::CADORecordset(_RecordsetPtr& rst)
{
	m_pRecordset = rst;
	m_strQuery = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_pRecBinding = NULL;
	m_nEditStatus = adoRstNone;
	m_nSearchDirection = adoRstForward;
}

CADORecordset::CADORecordset(CADORecordset& adoRst)
{
	m_pRecordset = adoRst.GetRecordset();
	m_strQuery = adoRst.m_strQuery;
	m_strLastError = adoRst.m_strLastError;
	m_dwLastError = adoRst.m_dwLastError;
	m_pRecBinding = adoRst.m_pRecBinding;
	m_nEditStatus = adoRst.m_nEditStatus;
	m_nSearchDirection = adoRst.m_nSearchDirection;
}

CADORecordset& CADORecordset::operator=(_RecordsetPtr& rst)
{
	m_pRecordset = rst;
	m_strQuery = _T("");
	m_strLastError = _T("");
	m_dwLastError = 0;
	m_pRecBinding = NULL;
	m_nEditStatus = adoRstNone;
	m_nSearchDirection = adoRstForward;

	return *this;
}

CADORecordset& CADORecordset::operator=(CADORecordset& adoRst)
{
	m_pRecordset = adoRst.GetRecordset();
	m_strQuery = adoRst.m_strQuery;
	m_strLastError = adoRst.m_strLastError;
	m_dwLastError = adoRst.m_dwLastError;
	m_pRecBinding = adoRst.m_pRecBinding;
	m_nEditStatus = adoRst.m_nEditStatus;
	m_nSearchDirection = adoRst.m_nSearchDirection;

	return *this;
}

BOOL CADORecordset::Open(_ConnectionPtr pConnection, CString strExec, int nOption)
{	
	Close();
	
	if(!strExec.IsEmpty())
		m_strQuery = strExec;

	ASSERT(!m_strQuery.IsEmpty());
	
	m_strQuery.TrimLeft();
	BOOL bIsSelect = m_strQuery.Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0 && nOption == adoRstUnknown;

	try
	{
		m_pRecordset->CursorType = adOpenStatic;
		m_pRecordset->CursorLocation = adUseClient;
		if(nOption == adoRstUnknown)
			m_pRecordset->Open((LPCSTR)(LPCTSTR)m_strQuery, _variant_t((IDispatch*)pConnection, TRUE), 
							adOpenForwardOnly, adLockReadOnly, adCmdUnknown);
		else if(bIsSelect || nOption == adoRstQuery)
			m_pRecordset->Open((LPCSTR)(LPCTSTR)m_strQuery, _variant_t((IDispatch*)pConnection, TRUE), 
			adOpenStatic, adLockOptimistic, adCmdText);
		else if(nOption == adoRstTable)
			m_pRecordset->Open((LPCSTR)(LPCTSTR)m_strQuery, _variant_t((IDispatch*)pConnection, TRUE), 
							adOpenKeyset, adLockOptimistic, adCmdTable);
		else if(nOption == adoRstStoredProc)
		{
			m_pRecordset->Open((LPCSTR)(LPCTSTR)m_strQuery, _variant_t((IDispatch*)pConnection, TRUE), 
				adOpenKeyset, adLockOptimistic, adCmdText);
// 			m_pCmd->ActiveConnection = pConnection;
// 			m_pCmd->CommandText = _bstr_t(m_strQuery);
// 			m_pCmd->CommandType = adCmdStoredProc;
// 			m_pConnection->CursorLocation = adUseClient;
// 			
// 			m_pRecordset = m_pCmd->Execute(NULL, NULL, adCmdText);
		}
		else
		{
			TRACE( _T("Unknown parameter. %d"), nOption);
			return FALSE;
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}

	return m_pRecordset != NULL;
}

BOOL CADORecordset::Open(CString strExec, int nOption)
{
	if(m_pRecordset)
	{
		_ConnectionPtr pConnection = m_pRecordset->GetActiveConnection().pdispVal;
		ASSERT(pConnection->GetState() != adStateClosed);
		return Open(pConnection, strExec, nOption);
	}
	
	return FALSE;
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, double& dbValue)
{	
	double val = (double)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt)
		{
		case VT_R4:
			val = vtFld.fltVal;
			break;
		case VT_R8:
			val = vtFld.dblVal;
			break;
		case VT_DECIMAL:
			//Corrected by Jos?Carlos Mart�nez Gal�n
			val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10.0, vtFld.decVal.scale); 
			break;
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_I2:
		case VT_I4:
			val = vtFld.lVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.dblVal;
		}
		dbValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, double& dbValue)
{	
	double val = (double)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt)
		{
		case VT_R4:
			val = vtFld.fltVal;
			break;
		case VT_R8:
			val = vtFld.dblVal;
			break;
		case VT_DECIMAL:
			//Corrected by Jos?Carlos Mart�nez Gal�n
			val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10.0, vtFld.decVal.scale); 
			break;
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_I2:
		case VT_I4:
			val = vtFld.lVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = 0;
		}
		dbValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, long& lValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.lVal;
		lValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, long& lValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.lVal;
		lValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, unsigned long& ulValue)
{
	unsigned long val = (unsigned long)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		ulValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, unsigned long& ulValue)
{
	unsigned long val = (unsigned long)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		ulValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, long long& llValue)
{
	long long val = (long long)NULL;
	_variant_t vtFld;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		llValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, long long& llValue)
{
	long long val = (long long)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		llValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, int& nValue)
{
	int val = NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt)
		{
		case VT_BOOL:
			val = vtFld.boolVal;
			break;
		case VT_I2:
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.iVal;
		}	
		nValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, int& nValue)
{
	int val = (int)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt)
		{
		case VT_BOOL:
			val = vtFld.boolVal;
			break;
		case VT_I2:
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.iVal;
		}	
		nValue = val;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, CString& strValue, CString strDateFormat)
{
	CString str = _T("");
	_variant_t vtFld;

	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_R4:
			str = DblToStr(vtFld.fltVal);
			break;
		case VT_R8:
			str = DblToStr(vtFld.dblVal);
			break;
		case VT_BSTR:
			str = vtFld.bstrVal;
			break;
		case VT_I2:
		case VT_UI1:
			str = IntToStr(vtFld.iVal);
			break;
		case VT_INT:
			str = IntToStr(vtFld.intVal);
			break;
		case VT_I4:
			str = LongToStr(vtFld.lVal);
			break;
		case VT_UI4:
			str = ULongToStr(vtFld.ulVal);
			break;
		case VT_DECIMAL:
			{
			//Corrected by Jos?Carlos Mart�nez Gal�n
			double val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10.0, vtFld.decVal.scale); 
			str = DblToStr(val);
			}
			break;
		case VT_DATE:
			{
				COleDateTime dt(vtFld);

				if(strDateFormat.IsEmpty())
					strDateFormat = _T("%Y-%m-%d %H:%M:%S");
				str = dt.Format(strDateFormat);
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			str.Empty();
			break;
		default:
			str.Empty();
			return FALSE;
		}
		strValue = str;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, CString& strValue, CString strDateFormat)
{
	CString str = _T("");
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_R4:
			str = DblToStr(vtFld.fltVal);
			break;
		case VT_R8:
			str = DblToStr(vtFld.dblVal);
			break;
		case VT_BSTR:
			str = vtFld.bstrVal;
			break;
		case VT_I2:
		case VT_UI1:
			str = IntToStr(vtFld.iVal);
			break;
		case VT_INT:
			str = IntToStr(vtFld.intVal);
			break;
		case VT_I4:
			str = LongToStr(vtFld.lVal);
			break;
		case VT_UI4:
			str = ULongToStr(vtFld.ulVal);
			break;
		case VT_DECIMAL:
			{
			//Corrected by Jos?Carlos Mart�nez Gal�n
			double val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10.0, vtFld.decVal.scale); 
			str = DblToStr(val);
			}
			break;
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				
				if(strDateFormat.IsEmpty())
					strDateFormat = _T("%Y-%m-%d %H:%M:%S");
				str = dt.Format(strDateFormat);
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			str.Empty();
			break;
		default:
			str.Empty();
			return FALSE;
		}
		strValue = str;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, COleDateTime& time)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				time = dt;
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			time.SetStatus(COleDateTime::null);
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, COleDateTime& time)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				time = dt;
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			time.SetStatus(COleDateTime::null);
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, bool& bValue)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_BOOL:
			bValue = vtFld.boolVal == VARIANT_TRUE ? true: false;
			break;
		case VT_EMPTY:
		case VT_NULL:
			bValue = false;
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, bool& bValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_BOOL:
			bValue = vtFld.boolVal == VARIANT_TRUE ? true: false;
			break;
		case VT_EMPTY:
		case VT_NULL:
			bValue = false;
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, COleCurrency& cyValue)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_CY:
			cyValue = (CURRENCY)vtFld.cyVal;
			break;
		case VT_EMPTY:
		case VT_NULL:
			{
			cyValue = COleCurrency();
			cyValue.m_status = COleCurrency::null;
			}
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, COleCurrency& cyValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_CY:
			cyValue = (CURRENCY)vtFld.cyVal;
			break;
		case VT_EMPTY:
		case VT_NULL:
			{
			cyValue = COleCurrency();
			cyValue.m_status = COleCurrency::null;
			}
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, COleVariant& vtValue)
{
	try
	{
		vtValue = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, COleVariant& vtValue)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtValue = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(CString strFieldName, _variant_t& vtValue)
{
	try
	{
		vtValue = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, _variant_t& vtValue)
{
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtValue = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::IsFieldNull(CString strFieldName)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		return vtFld.vt == VT_NULL;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::IsFieldNull(int nIndex)
{
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		return vtFld.vt == VT_NULL;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::IsFieldEmpty(CString strFieldName)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value;
		return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::IsFieldEmpty(int nIndex)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
		return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::SetFieldEmpty(CString strFieldName)
{
	_variant_t vtFld;
	vtFld.vt = VT_EMPTY;
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldEmpty(int nIndex)
{
	_variant_t vtFld;
	vtFld.vt = VT_EMPTY;

	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

DWORD CADORecordset::GetRecordCount()
{
	DWORD nRows = 0;
	
	nRows = m_pRecordset->GetRecordCount();

	if(nRows == -1)
	{
		nRows = 0;
		if(m_pRecordset->_EOF != VARIANT_TRUE)
			m_pRecordset->MoveFirst();
		
		while(m_pRecordset->_EOF != VARIANT_TRUE)
		{
			nRows++;
			m_pRecordset->MoveNext();
		}
		if(nRows > 0)
			m_pRecordset->MoveFirst();
	}
	
	return nRows;
}

BOOL CADORecordset::IsOpen()
{
	if(m_pRecordset)
		return m_pRecordset->GetState() != adStateClosed;
	return FALSE;
}

void CADORecordset::Close()
{
	if(IsOpen())
	{
		if (m_nEditStatus != adoRstNone) CancelUpdate();
		m_pRecordset->Close();
	}
}

BOOL  CADORecordset::IsConnectionOpen()
{
	if(m_pRecordset)
	{
		_ConnectionPtr pConnection = m_pRecordset->GetActiveConnection().pdispVal;
		return pConnection->GetState() != adStateClosed;
	}
	return FALSE;
}

_ConnectionPtr CADORecordset::GetConnection()
{
	if(m_pRecordset)
		return m_pRecordset->GetActiveConnection().pdispVal;

	return NULL;
}

BOOL CADORecordset::RecordBinding(CADORecordBinding &pAdoRecordBinding)
{
	HRESULT hr;
	m_pRecBinding = NULL;

	//Open the binding interface.
	if(FAILED(hr = m_pRecordset->QueryInterface(__uuidof(IADORecordBinding), (LPVOID*)&m_pRecBinding )))
	{
		_com_issue_error(hr);
		return FALSE;
	}
	
	//Bind the recordset to class
	if(FAILED(hr = m_pRecBinding->BindToRecordset(&pAdoRecordBinding)))
	{
		_com_issue_error(hr);
		return FALSE;
	}
	return TRUE;
}

BOOL CADORecordset::GetFieldInfo(CString strFieldName, Stru_AdoFieldInfo* fldInfo)
{
	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);
	
	return GetFieldInfo(pField, fldInfo);
}

BOOL CADORecordset::GetFieldInfo(int nIndex, Stru_AdoFieldInfo* fldInfo)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);

	return GetFieldInfo(pField, fldInfo);
}

BOOL CADORecordset::GetFieldInfo(_FieldPtr pField, Stru_AdoFieldInfo* fldInfo)
{
	memset(fldInfo, 0, sizeof(Stru_AdoFieldInfo));

	strcpy_s(fldInfo->m_strName, (LPCSTR)(LPCTSTR)pField->GetName());
	fldInfo->m_lDefinedSize = pField->GetDefinedSize();
	fldInfo->m_nType = pField->GetType();
	fldInfo->m_lAttributes = pField->GetAttributes();
	if(!IsEOF())
		fldInfo->m_lSize = pField->GetActualSize();
	return TRUE;
}

BOOL CADORecordset::GetChunk(CString strFieldName, CString& strValue)
{
	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);
	
	return GetChunk(pField, strValue);
}

BOOL CADORecordset::GetChunk(int nIndex, CString& strValue)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);
	
	return GetChunk(pField, strValue);
}

BOOL CADORecordset::GetChunk(_FieldPtr pField, CString& strValue)
{
	CString str = _T("");
	long lngSize, lngOffSet = 0;
	_variant_t varChunk;

	lngSize = pField->ActualSize;
	
	str.Empty();
	while(lngOffSet < lngSize)
	{ 
		try
		{
			varChunk = pField->GetChunk(ChunkSize);
			
			str += varChunk.bstrVal;
			lngOffSet += ChunkSize;
		}
		catch(_com_error &e)
		{
			dump_com_error(e);
			return FALSE;
		}
	}

	lngOffSet = 0;
	strValue = str;
	return TRUE;
}

BOOL CADORecordset::GetChunk(CString strFieldName, LPVOID lpData)
{
	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);

	return GetChunk(pField, lpData);
}

BOOL CADORecordset::GetChunk(int nIndex, LPVOID lpData)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);

	return GetChunk(pField, lpData);
}

BOOL CADORecordset::GetChunk(_FieldPtr pField, LPVOID lpData)
{
	long lngSize, lngOffSet = 0;
	_variant_t varChunk;    
	UCHAR chData;
	HRESULT hr;
	long lBytesCopied = 0;

	lngSize = pField->ActualSize;
	
	while(lngOffSet < lngSize)
	{ 
		try
		{
			varChunk = pField->GetChunk(ChunkSize);

			//Copy the data only upto the Actual Size of Field.  
            for(long lIndex = 0; lIndex <= (ChunkSize - 1); lIndex++)
            {
                hr= SafeArrayGetElement(varChunk.parray, &lIndex, &chData);
                if(SUCCEEDED(hr))
                {
                    //Take BYTE by BYTE and advance Memory Location
                    //hr = SafeArrayPutElement((SAFEARRAY FAR*)lpData, &lBytesCopied ,&chData); 
					((UCHAR*)lpData)[lBytesCopied] = chData;
                    lBytesCopied++;
                }
                else
                    break;
            }
			lngOffSet += ChunkSize;
		}
		catch(_com_error &e)
		{
			dump_com_error(e);
			return FALSE;
		}
	}

	lngOffSet = 0;
	return TRUE;
}

BOOL CADORecordset::GetChunk(CString strFieldName, CFile *pFile)
{
	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);
	
	return GetChunk(pField, pFile);
}

BOOL CADORecordset::GetChunk(int nIndex,CFile *pFile)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);
	
	return GetChunk(pField, pFile);
}

BOOL CADORecordset::GetChunk(_FieldPtr pField, CFile *pFile)
{
	long lngSize = pField->ActualSize;
	
	UCHAR *pBuf = new UCHAR[lngSize];
	memset(pBuf,NULL,lngSize);

	GetChunk(pField,pBuf);
	
	pFile->SeekToBegin();
	pFile->Write(pBuf,lngSize);
	pFile->SeekToBegin();
	
	delete pBuf;
	
	return TRUE;
}

BOOL CADORecordset::SetChunkFromFile(_FieldPtr pField, CFile *pFile)
{
	ULONG len = (ULONG)pFile->GetLength();
	pFile->SeekToBegin();
	UCHAR *lpData = new UCHAR[len];
	memset(lpData,0,len);
	pFile->Read(lpData,len);
	
	BOOL bret = AppendChunk(pField, lpData, len);
	
	delete lpData;
	
	return bret;
}

BOOL CADORecordset::AppendChunk(CString strFieldName, LPVOID lpData, UINT nBytes)
{

	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);

	return AppendChunk(pField, lpData, nBytes);
}

BOOL CADORecordset::AppendChunk(int nIndex, LPVOID lpData, UINT nBytes)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);

	return AppendChunk(pField, lpData, nBytes);
}

BOOL CADORecordset::AppendChunk(CString strFieldName, CFile *pFile)
{
	_FieldPtr pField = m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName);
	
	return SetChunkFromFile(pField, pFile);
	
}

BOOL CADORecordset::AppendChunk(int nIndex, CFile *pFile)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	_FieldPtr pField = m_pRecordset->Fields->GetItem(vtIndex);
	
	return SetChunkFromFile(pField, pFile);
	
}

BOOL CADORecordset::AppendChunk(_FieldPtr pField, LPVOID lpData, UINT nBytes)
{
	HRESULT hr;
	_variant_t varChunk;
	long lngOffset = 0;
	UCHAR chData;
	SAFEARRAY FAR *psa = NULL;
	SAFEARRAYBOUND rgsabound[1];

	try
	{
		//Create a safe array to store the array of BYTES 
		rgsabound[0].lLbound = 0;
		rgsabound[0].cElements = nBytes;
		psa = SafeArrayCreate(VT_UI1,1,rgsabound);

		while(lngOffset < (long)nBytes)
		{
			chData	= ((UCHAR*)lpData)[lngOffset];
			hr = SafeArrayPutElement(psa, &lngOffset, &chData);

			if(FAILED(hr))
				return FALSE;
			
			lngOffset++;
		}
		lngOffset = 0;

		//Assign the Safe array  to a variant. 
		varChunk.vt = VT_ARRAY|VT_UI1;
		varChunk.parray = psa;

		hr = pField->AppendChunk(varChunk);

		if(SUCCEEDED(hr))
			return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}

	return FALSE;
}

CString CADORecordset::GetString(CString strCols, CString strRows, CString strNull, long numRows)
{
	_bstr_t varOutput;
	_bstr_t varNull(_T(""));
	_bstr_t varCols(_T("\t"));
	_bstr_t varRows(_T("\r"));

	if(!strCols.IsEmpty())
		varCols = _bstr_t(strCols);

	if(strRows.IsEmpty())
		varRows = _bstr_t(strRows);
	
	if(numRows == 0)
		numRows =(long)GetRecordCount();			
			
	varOutput = m_pRecordset->GetString(adClipString, numRows, varCols, varRows, varNull);

	return CString((LPCTSTR)varOutput);
}

void CADORecordset::Edit()
{
	m_nEditStatus = adoRstEdit;
}

BOOL CADORecordset::AddNew()
{
	m_nEditStatus = adoRstNone;
	if(m_pRecordset->AddNew() != S_OK)
		return FALSE;

	m_nEditStatus = adoRstNew;
	return TRUE;
}

BOOL CADORecordset::AddNew(CADORecordBinding &pAdoRecordBinding)
{
	try
	{
		if(m_pRecBinding->AddNew(&pAdoRecordBinding) != S_OK)
		{
			return FALSE;
		}
		else
		{
			m_pRecBinding->Update(&pAdoRecordBinding);
			return TRUE;
		}
			
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}	
}

BOOL CADORecordset::Update()
{
	BOOL bret = TRUE;

	if(m_nEditStatus != adoRstNone)
	{

		try
		{
			if(m_pRecordset->Update() != S_OK)
				bret = FALSE;
		}
		catch(_com_error &e)
		{
			dump_com_error(e);
			bret = FALSE;
		}

		if(!bret)
			m_pRecordset->CancelUpdate();
		m_nEditStatus = adoRstNone;
	}
	return bret;
}

void CADORecordset::CancelUpdate()
{
	m_pRecordset->CancelUpdate();
	m_nEditStatus = adoRstNone;
}

BOOL CADORecordset::SetFieldValue(int nIndex, CString strValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;	
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	if(!strValue.IsEmpty())
		vtFld.vt = VT_BSTR;
	else
		vtFld.vt = VT_NULL;

	//Corrected by Giles Forster 10/03/2001
	vtFld.bstrVal = strValue.AllocSysString();

	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, CString strValue)
{
	_variant_t vtFld;

	if(!strValue.IsEmpty())
		vtFld.vt = VT_BSTR;
	else
		vtFld.vt = VT_NULL;

	//Corrected by Giles Forster 10/03/2001
	vtFld.bstrVal = strValue.AllocSysString();

	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, int nValue)
{
	_variant_t vtFld;
	
	vtFld.vt = VT_I2;
	vtFld.iVal = nValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, int nValue)
{
	_variant_t vtFld;
	
	vtFld.vt = VT_I2;
	vtFld.iVal = nValue;
	
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, long lValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I4;
	vtFld.lVal = lValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
	
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, long lValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I4;
	vtFld.lVal = lValue;
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, unsigned long ulValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_UI4;
	vtFld.ulVal = ulValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
	
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, unsigned long ulValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_UI4;
	vtFld.ulVal = ulValue;
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, long long llValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I8;
	vtFld.ulVal = llValue;

	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	return PutFieldValue(vtIndex, vtFld);

}

BOOL CADORecordset::SetFieldValue(CString strFieldName, long long llValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I8;
	vtFld.ulVal = llValue;

	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, double dblValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_R8;
	vtFld.dblVal = dblValue;

	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, double dblValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_R8;
	vtFld.dblVal = dblValue;
		
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, COleDateTime time)
{
	_variant_t vtFld;
	vtFld.vt = VT_DATE;
	vtFld.date = time;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, COleDateTime time)
{
	_variant_t vtFld;
	vtFld.vt = VT_DATE;
	vtFld.date = time;
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, bool bValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_BOOL;
	vtFld.boolVal = bValue ? VARIANT_TRUE: VARIANT_FALSE;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, bool bValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_BOOL;
	vtFld.boolVal = bValue ? VARIANT_TRUE: VARIANT_FALSE;
	
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, COleCurrency cyValue)
{
	if(cyValue.m_status == COleCurrency::invalid)
		return FALSE;

	_variant_t vtFld;
		
	vtFld.vt = VT_CY;
	vtFld.cyVal = cyValue.m_cur;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, COleCurrency cyValue)
{
	if(cyValue.m_status == COleCurrency::invalid)
		return FALSE;

	_variant_t vtFld;

	vtFld.vt = VT_CY;
	vtFld.cyVal = cyValue.m_cur;	
		
	return PutFieldValue(strFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, COleVariant vtValue)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtValue);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, COleVariant vtValue)
{	
	return PutFieldValue(strFieldName, vtValue);
}

BOOL CADORecordset::SetFieldValue(int nIndex, _variant_t vtValue)
{
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	return PutFieldValue(vtIndex, vtValue);
}

BOOL CADORecordset::SetFieldValue(CString strFieldName, _variant_t vtValue)
{	
	return PutFieldValue(strFieldName, vtValue);
}

BOOL CADORecordset::SetBookmark(_variant_t varBookmark)
{
	if(varBookmark.vt != VT_EMPTY)
	{
		m_pRecordset->Bookmark = varBookmark;
		m_varBookmark = varBookmark;
		return TRUE;
	}
	return FALSE;
}

BOOL CADORecordset::Delete()
{
	if(m_pRecordset->Delete(adAffectCurrent) != S_OK) return FALSE;

	if(m_pRecordset->Update() != S_OK) return FALSE;
	
	m_nEditStatus = adoRstNone;
	return TRUE;
}

BOOL CADORecordset::Find(CString strFind, int nSearchDirection)
{

	m_strFind = strFind;
	m_nSearchDirection = nSearchDirection;

	ASSERT(!m_strFind.IsEmpty());

	if(m_nSearchDirection == adoRstForward)
	{
		m_pRecordset->Find(_bstr_t(m_strFind), 0, adSearchForward, _T(""));
		if(!IsEOF())
		{
			m_varBookFind = m_pRecordset->Bookmark;
			return TRUE;
		}
	}
	else if(m_nSearchDirection == adoRstBackward)
	{
		m_pRecordset->Find(_bstr_t(m_strFind), 0, adSearchBackward, _T(""));
		if(!IsBOF())
		{
			m_varBookFind = m_pRecordset->Bookmark;
			return TRUE;
		}
	}
	else
	{
		TRACE(_T("Unknown parameter. %d"), nSearchDirection);
		m_nSearchDirection = adoRstForward;
	}
	return FALSE;
}

BOOL CADORecordset::FindFirst(CString strFind)
{
	m_pRecordset->MoveFirst();
	return Find(strFind);
}

BOOL CADORecordset::FindNext()
{
	if(m_nSearchDirection == adoRstForward)
	{
		m_pRecordset->Find(_bstr_t(m_strFind), 1, adSearchForward, m_varBookFind);
		if(!IsEOF())
		{
			m_varBookFind = m_pRecordset->Bookmark;
			return TRUE;
		}
	}
	else
	{
		m_pRecordset->Find(_bstr_t(m_strFind), 1, adSearchBackward, m_varBookFind);
		if(!IsBOF())
		{
			m_varBookFind = m_pRecordset->Bookmark;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CADORecordset::PutFieldValue(CString strFieldName, _variant_t vtFld)
{
	if(m_nEditStatus == adoRstNone) return FALSE;
	
	try
	{
		m_pRecordset->Fields->GetItem((LPCTSTR)strFieldName)->Value = vtFld; 
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;	
	}
}

BOOL CADORecordset::PutFieldValue(_variant_t vtIndex, _variant_t vtFld)
{
	if(m_nEditStatus == adoRstNone) return FALSE;

	try
	{
		m_pRecordset->Fields->GetItem(vtIndex)->Value = vtFld;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::Clone(CADORecordset &pRst)
{
	try
	{
		pRst.m_pRecordset = m_pRecordset->Clone(adLockUnspecified);
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::Clone(_RecordsetPtr &pRst)
{
	try
	{
		pRst = m_pRecordset->Clone(adLockUnspecified);
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::SetFilter(CString strFilter)
{
	ASSERT(IsOpen());
	
	try
	{
		m_pRecordset->PutFilter((LPCTSTR)strFilter);
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::SetSort(CString strCriteria)
{
	ASSERT(IsOpen());
	
	try
	{
		m_pRecordset->PutSort((LPCTSTR)strCriteria);
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::SaveAsXML(CString strXMLFile)
{
	HRESULT hr;

	ASSERT(IsOpen());
	
	try
	{
		hr = m_pRecordset->Save((LPCTSTR)strXMLFile, adPersistXML);
		return hr == S_OK;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
	return TRUE;
}

BOOL CADORecordset::OpenXML(CString strXMLFile)
{
	HRESULT hr = S_OK;

	if(IsOpen())
		Close();

	try
	{
		hr = m_pRecordset->Open((LPCTSTR)strXMLFile, _T("Provider=MSPersist;"), adOpenForwardOnly, adLockOptimistic, adCmdFile);
		return hr == S_OK;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADORecordset::Execute(CADOCommand& adoCommand)
{
	if(IsOpen()) Close();

	ASSERT(!adoCommand.GetText().IsEmpty());
	try
	{
		if(m_pRecordset)
		{
			_ConnectionPtr pConnection = m_pRecordset->GetActiveConnection().pdispVal;
			pConnection->CursorLocation = adUseClient;
			_variant_t vRecords,vNull;
			vNull.vt = VT_ERROR;
			vNull.scode = DISP_E_PARAMNOTFOUND;

			adoCommand.GetText().TrimLeft();
			BOOL bIsSelect = adoCommand.GetText().Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0;
			if(bIsSelect)
			{
				m_pRecordset = adoCommand.GetCommand()->Execute(&vRecords, &vNull, adCmdText/*adExecuteRecord*/);
				return TRUE;
			}
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}

	return FALSE;
}

void CADORecordset::dump_com_error(_com_error &e)
{
	CString ErrorStr;

	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CADORecordset Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription);
	m_strLastError = _T("Query = ") + GetQuery() + _T("\n") + ErrorStr;
	m_dwLastError = e.Error();
	#ifdef _DEBUG
		AfxMessageBox( ErrorStr, MB_OK | MB_ICONERROR );
	#endif
}

_variant_t CADORecordset::GetRows()
{
	long rs = m_pRecordset->GetRecordCount();
	return m_pRecordset->GetRows(rs);
}



///////////////////////////////////////////////////////
//
// CADOParameter Class
//

CADOParameter::CADOParameter(int nType, long lSize, int nDirection, CString strName)
{
	m_pParameter = NULL;
	m_pParameter.CreateInstance(__uuidof(Parameter));
	m_pParameter->Direction = (_ParameterDirectionEnum)nDirection;
	m_strName = strName;
	m_pParameter->Name = m_strName.AllocSysString();
	m_pParameter->Type = (_DataTypeEnum)nType;
	m_pParameter->Size = lSize;
}

CADOParameter::CADOParameter(_ParameterPtr& para)
{
	m_pParameter = para;
	m_strName = (LPCSTR)para->Name;
}

CADOParameter::CADOParameter(CADOParameter& adoPara)
{
	m_pParameter = adoPara.GetParameter();
	m_strName = (LPCSTR)adoPara.GetParameter()->Name;
}

CADOParameter& CADOParameter::operator=(_ParameterPtr& para)
{
	m_pParameter = para;
	m_strName = (LPCSTR)para->Name;

	return *this;
}

CADOParameter& CADOParameter::operator=(CADOParameter& adoPara)
{
	m_pParameter = adoPara.GetParameter();
	m_strName = (LPCSTR)adoPara.GetParameter()->Name;

	return *this;
}

BOOL CADOParameter::SetValue(int nValue)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	vtVal.vt = VT_I2;
	vtVal.iVal = nValue;

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(int);

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(bool bValue)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	vtVal.vt = VT_BOOL;
	vtVal.boolVal = bValue ? VARIANT_TRUE:VARIANT_FALSE;

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(short);

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(long lValue)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	vtVal.vt = VT_I4;
	vtVal.lVal = lValue;

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(long);

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(double dblValue)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	vtVal.vt = VT_R8;
	vtVal.dblVal = dblValue;

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(double);

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(CString strValue)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	if(!strValue.IsEmpty())
		vtVal.vt = VT_BSTR;
	else
		vtVal.vt = VT_NULL;

	//Corrected by Giles Forster 10/03/2001
	vtVal.bstrVal = strValue.AllocSysString();

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(char) * strValue.GetLength();

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(COleDateTime time)
{
	_variant_t vtVal;

	ASSERT(m_pParameter != NULL);

	vtVal.vt = VT_DATE;
	vtVal.date = time;

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(DATE);

		m_pParameter->Value = vtVal;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::SetValue(_variant_t vtValue)
{

	ASSERT(m_pParameter != NULL);

	try
	{
		if(m_pParameter->Size == 0)
			m_pParameter->Size = sizeof(VARIANT);

		m_pParameter->Value = vtValue;
		return TRUE;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(int& nValue)
{
	_variant_t vtVal;
	int nVal = 0;

	try
	{
		vtVal = m_pParameter->Value;

		switch(vtVal.vt)
		{
		case VT_BOOL:
			nVal = vtVal.boolVal;
			break;
		case VT_I2:
		case VT_UI1:
			nVal = vtVal.iVal;
			break;
		case VT_INT:
			nVal = vtVal.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			nVal = 0;
			break;
		default:
			nVal = vtVal.iVal;
		}	
		nValue = nVal;
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(long& lValue)
{
	_variant_t vtVal;
	long lVal = 0;

	try
	{
		vtVal = m_pParameter->Value;
		if(vtVal.vt != VT_NULL && vtVal.vt != VT_EMPTY)
			lVal = vtVal.lVal;
		lValue = lVal;
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(double& dbValue)
{
	_variant_t vtVal;
	double dblVal;
	try
	{
		vtVal = m_pParameter->Value;
		switch(vtVal.vt)
		{
		case VT_R4:
			dblVal = vtVal.fltVal;
			break;
		case VT_R8:
			dblVal = vtVal.dblVal;
			break;
		case VT_DECIMAL:
			//Corrected by Jos?Carlos Mart�nez Gal�n
			dblVal = vtVal.decVal.Lo32;
			dblVal *= (vtVal.decVal.sign == 128)? -1 : 1;
			dblVal /= pow(10.0, vtVal.decVal.scale); 
			break;
		case VT_UI1:
			dblVal = vtVal.iVal;
			break;
		case VT_I2:
		case VT_I4:
			dblVal = vtVal.lVal;
			break;
		case VT_INT:
			dblVal = vtVal.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			dblVal = 0;
			break;
		default:
			dblVal = 0;
		}
		dbValue = dblVal;
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(CString& strValue, CString strDateFormat)
{
	_variant_t vtVal;
	CString strVal = _T("");

	try
	{
		vtVal = m_pParameter->Value;
		switch(vtVal.vt) 
		{
		case VT_R4:
			strVal = DblToStr(vtVal.fltVal);
			break;
		case VT_R8:
			strVal = DblToStr(vtVal.dblVal);
			break;
		case VT_BSTR:
			strVal = vtVal.bstrVal;
			break;
		case VT_I2:
		case VT_UI1:
			strVal = IntToStr(vtVal.iVal);
			break;
		case VT_INT:
			strVal = IntToStr(vtVal.intVal);
			break;
		case VT_I4:
			strVal = LongToStr(vtVal.lVal);
			break;
		case VT_DECIMAL:
			{
				//Corrected by Jos?Carlos Mart�nez Gal�n
				double val = vtVal.decVal.Lo32;
				val *= (vtVal.decVal.sign == 128)? -1 : 1;
				val /= pow(10.0, vtVal.decVal.scale); 
				strVal = DblToStr(val);
			}
			break;
		case VT_DATE:
			{
				COleDateTime dt(vtVal);

				if(strDateFormat.IsEmpty())
					strDateFormat = _T("%Y-%m-%d %H:%M:%S");
				strVal = dt.Format(strDateFormat);
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			strVal.Empty();
			break;
		default:
			strVal.Empty();
			return FALSE;
		}
		strValue = strVal;
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(COleDateTime& time)
{
	_variant_t vtVal;

	try
	{
		vtVal = m_pParameter->Value;
		switch(vtVal.vt) 
		{
		case VT_DATE:
			{
				COleDateTime dt(vtVal);
				time = dt;
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			time.SetStatus(COleDateTime::null);
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOParameter::GetValue(_variant_t& vtValue)
{
	try
	{
		vtValue = m_pParameter->Value;
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

void CADOParameter::dump_com_error(_com_error &e)
{
	CString ErrorStr;


	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CADOParameter Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription );
	m_strLastError = ErrorStr;
	m_dwLastError = e.Error();
#ifdef _DEBUG
	AfxMessageBox(ErrorStr, MB_OK | MB_ICONERROR);
#endif	
}



///////////////////////////////////////////////////////
//
// CADOCommad Class
//

CADOCommand::CADOCommand(CADOConnection& adoConnection, CString strCommandText, int nCommandType)
{
	m_pCommand = NULL;
	m_pCommand.CreateInstance(__uuidof(Command));

	m_strCommandText = strCommandText;
	m_pCommand->CommandText = (_bstr_t)m_strCommandText;
	m_nCommandType = nCommandType;
	m_pCommand->CommandType = (CommandTypeEnum)m_nCommandType;
	m_pCommand->ActiveConnection = adoConnection.GetConnection();
	m_pCommand->ActiveConnection->CursorLocation = adUseClient;
	m_nRecordsAffected = 0;
	m_strLastError = _T("");
	m_dwLastError = 0;
}

CADOCommand::CADOCommand(_CommandPtr& cmd)
{
	m_pCommand = cmd;
	m_strCommandText = (LPCSTR)m_pCommand->CommandText;
	m_nCommandType = m_pCommand->CommandType;
	m_nRecordsAffected = 0;
	m_strLastError = _T("");
	m_dwLastError = 0;
}

CADOCommand::CADOCommand(CADOCommand& adoCmd)
{
	m_pCommand = adoCmd.GetCommand();
	m_nCommandType = adoCmd.GetType();
	m_nRecordsAffected = 0;
	m_strCommandText = adoCmd.GetText();
	m_strLastError = _T("");
	m_dwLastError = 0;
}

CADOCommand& CADOCommand::operator=(_CommandPtr& cmd)
{
	m_pCommand = cmd;
	m_strCommandText = (LPCSTR)m_pCommand->CommandText;
	m_nCommandType = m_pCommand->CommandType;
	m_nRecordsAffected = 0;
	m_strLastError = _T("");
	m_dwLastError = 0;

	return *this;
}

CADOCommand& CADOCommand::operator=(CADOCommand& adoCmd)
{
	m_pCommand = adoCmd.GetCommand();
	m_nCommandType = adoCmd.GetType();
	m_nRecordsAffected = 0;
	m_strCommandText = adoCmd.GetText();
	m_strLastError = _T("");
	m_dwLastError = 0;

	return *this;
}

BOOL CADOCommand::RefreshParam()
{
	HRESULT ret = m_pCommand->Parameters->Refresh();
	return ret == S_OK;
}

BOOL CADOCommand::MakeInParam(CString strName, int nType, long lSize, _variant_t vtValue, int nPrecision, int nScale)
{
	try
	{
		_ParameterPtr pParam = m_pCommand->CreateParameter(strName.AllocSysString(), (_DataTypeEnum)nType, adParamInput, lSize, vtValue);
		pParam->PutPrecision(nPrecision);
		pParam->PutNumericScale(nScale);
		m_pCommand->Parameters->Append(pParam);

		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOCommand::MakeOutParam(CString strName, int nType, long lSize, _variant_t vtValue, int nPrecision, int nScale)
{
	try
	{
		_ParameterPtr pParam = m_pCommand->CreateParameter(strName.AllocSysString(), (_DataTypeEnum)nType, adParamOutput, lSize, vtValue);
		pParam->PutPrecision(nPrecision);
		pParam->PutNumericScale(nScale);
		m_pCommand->Parameters->Append(pParam);

		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOCommand::AddParameter(CADOParameter* pAdoParameter)
{
	ASSERT(pAdoParameter->GetParameter() != NULL);

	try
	{
		m_pCommand->Parameters->Append(pAdoParameter->GetParameter());
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, int nValue)
{

	_variant_t vtValue;

	vtValue.vt = VT_I2;
	vtValue.iVal = nValue;

	return AddParameter(strName, nType, nDirection, lSize, vtValue);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, bool bValue)
{

	_variant_t vtValue;

	vtValue.vt = VT_BOOL;
	vtValue.boolVal = bValue ? VARIANT_TRUE:VARIANT_FALSE;

	return AddParameter(strName, nType, nDirection, lSize, vtValue);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, long lValue)
{

	_variant_t vtValue;

	vtValue.vt = VT_I4;
	vtValue.lVal = lValue;

	return AddParameter(strName, nType, nDirection, lSize, vtValue);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, double dblValue, int nPrecision, int nScale)
{

	_variant_t vtValue;

	vtValue.vt = VT_R8;
	vtValue.dblVal = dblValue;

	return AddParameter(strName, nType, nDirection, lSize, vtValue, nPrecision, nScale);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, CString strValue)
{

	_variant_t vtValue;

	vtValue.vt = VT_BSTR;
	vtValue.bstrVal = strValue.AllocSysString();

	return AddParameter(strName, nType, nDirection, lSize, vtValue);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, COleDateTime time)
{

	_variant_t vtValue;

	vtValue.vt = VT_DATE;
	vtValue.date = time;

	return AddParameter(strName, nType, nDirection, lSize, vtValue);
}

BOOL CADOCommand::AddParameter(CString strName, int nType, int nDirection, long lSize, _variant_t vtValue, int nPrecision, int nScale)
{
	try
	{
		_ParameterPtr pParam = m_pCommand->CreateParameter(strName.AllocSysString(), (_DataTypeEnum)nType, (_ParameterDirectionEnum)nDirection, lSize, vtValue);
		pParam->PutPrecision(nPrecision);
		pParam->PutNumericScale(nScale);
		m_pCommand->Parameters->Append(pParam);
		
		return TRUE;
	}
	catch(_com_error& e)
	{
		dump_com_error(e);
		return FALSE;
	}
}

void CADOCommand::SetText(CString strCommandText)
{
	ASSERT(!strCommandText.IsEmpty());

	m_strCommandText = strCommandText;
	m_pCommand->CommandText = m_strCommandText.AllocSysString();
}

void CADOCommand::SetType(int nCommandType)
{
	m_nCommandType = nCommandType;
	m_pCommand->CommandType = (CommandTypeEnum)m_nCommandType;
}

void CADOCommand::SetPrepared(BOOL bPrepared)
{
	bPrepared ? m_pCommand->Prepared = VARIANT_TRUE : m_pCommand->Prepared = VARIANT_FALSE;
}

BOOL CADOCommand::GetPrepared()
{
	if(m_pCommand->Prepared == VARIANT_TRUE)
		return TRUE;
	else if(m_pCommand->Prepared == VARIANT_FALSE)
		return FALSE;

	return FALSE;
}

int CADOCommand::Execute(_RecordsetPtr& pRecordset)
{
	m_nRecordsAffected = 0;

	try
	{
		m_strCommandText.TrimLeft();
		BOOL bIsSelect = m_strCommandText.Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0;

		_variant_t vRecords,vNull;
		vNull.vt = VT_ERROR;
		vNull.scode = DISP_E_PARAMNOTFOUND;

		if(bIsSelect)
		{
			pRecordset = m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			if(pRecordset) m_nRecordsAffected = pRecordset->GetRecordCount();
		}
		else
		{
			m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			m_nRecordsAffected = vRecords.iVal;
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}

	return m_nRecordsAffected;
}

int CADOCommand::Execute(CADORecordset& rst)
{
	m_nRecordsAffected = 0;

	try
	{
		m_strCommandText.TrimLeft();
		BOOL bIsSelect = m_strCommandText.Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0;

		_variant_t vRecords,vNull;
		vNull.vt = VT_ERROR;
		vNull.scode = DISP_E_PARAMNOTFOUND;

		if(bIsSelect)
		{
			rst = m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			if(rst.IsOpen()) m_nRecordsAffected = rst.GetRecordCount();
		}
		else
		{
			m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			m_nRecordsAffected = vRecords.iVal;
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}

	return m_nRecordsAffected;
}

int CADOCommand::Execute()
{
	m_nRecordsAffected = 0;

	try
	{
		m_strCommandText.TrimLeft();
		BOOL bIsSelect = m_strCommandText.Mid(0, strlen("select ")).CompareNoCase(_T("select ")) == 0;

		_variant_t vRecords,vNull;
		vNull.vt = VT_ERROR;
		vNull.scode = DISP_E_PARAMNOTFOUND;

		if(bIsSelect)
		{
			_RecordsetPtr pRecordset = NULL;
			pRecordset.CreateInstance(__uuidof(Recordset));
			pRecordset->CursorType = adOpenKeyset;
			pRecordset->LockType = adLockOptimistic;
			pRecordset->CursorLocation = adUseClient;
			pRecordset = m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			if(pRecordset)
			{
				//LPVOID pRstVoid=(IUnknown*)pRecordset;
				//_RecordsetPtr pRst = (_RecordsetPtr)(IUnknown*)pRstVoid;
				m_nRecordsAffected = pRecordset->GetRecordCount();
				pRecordset.Release();
				pRecordset = NULL;
			}
		}
		else
		{
			m_pCommand->Execute(&vRecords, &vNull, m_nCommandType/*adExecuteNoRecords*/);
			m_nRecordsAffected = vRecords.iVal;
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}

	return m_nRecordsAffected;
}

void CADOCommand::dump_com_error(_com_error &e)
{
	CString ErrorStr;
	
	
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CADOCommand Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription );
	m_strLastError = ErrorStr;
	m_dwLastError = e.Error();
	#ifdef _DEBUG
		AfxMessageBox(ErrorStr, MB_OK | MB_ICONERROR);
	#endif	
}



///////////////////////////////////////////////////////
//
// CADOException Class
//
IMPLEMENT_DYNAMIC(CADOException, CException)

CADOException::CADOException(int nCause, CString strErrorString) : CException(TRUE)
{
	m_nCause = nCause;
	m_strErrorString = strErrorString;
}

CADOException::~CADOException()
{

}

int CADOException::GetError(int nADOError)
{
	switch (nADOError)
	{
	case noError:
		return CADOException::noError;
		break;
	default:
		return CADOException::Unknown;
	}
	
}

void AfxThrowADOException(int nADOError, CString strErrorString)
{
	throw new CADOException(CADOException::GetError(nADOError), strErrorString);
}