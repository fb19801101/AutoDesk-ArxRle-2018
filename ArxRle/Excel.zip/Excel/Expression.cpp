#include "stdafx.h"
#include "math.h"
#include "Expression.h"

CExpression::CExpression()
{
	m_pbranch = NULL;
	m_definitie = "";
	pozitie = 0;
	m_pvariable = NULL;
}

CExpression::CExpression(CMapVariable* vars)
{
	m_pbranch = NULL;
	m_definitie = "";
	pozitie = 0;
	m_pvariable = vars;
}

CExpression::CExpression(CExpression& expr)
{
	*this = expr;
}

CExpression::~CExpression()
{
	release(m_pbranch);
}

CExpression& CExpression::operator=(CExpression& expr)
{
	m_definitie = expr.m_definitie;
	m_pvariable = expr.m_pvariable;
	pozitie = 0;
	m_pbranch = expr.CloneBranch();
	return *this;
}

void CExpression::AtachVariables(CMapVariable* vars)
{
	m_pvariable = vars;
}

void CExpression::Serialize(CArchive& branch)
{
	if(branch.IsStoring())
	{
		branch << m_definitie;
	}
	else
	{
		branch >> m_definitie;
		m_pbranch = NULL;
		pozitie = 0;
		UpdateBranch();
		// After loading this object if it contains variables you should atach a variable 
		// Table to it
	}
}

int CExpression::UpdateBranch()
{
	if(m_definitie.IsEmpty()) return 0;
	release(m_pbranch); // Eliberarea memoriei ocupate de BranchPtr
	m_pbranch = NULL;
	pozitie = 0;
	m_pbranch = addcut();
	if(m_definitie[pozitie]!='\0') 
	{
		release(m_pbranch);
		m_pbranch = NULL;
	}

	if(m_pbranch == NULL) return pozitie;
	else return -1;
}

int CExpression::ChangeExpression(CString& expresie)
{
	m_definitie = expresie + '\0' + '\0';
	return UpdateBranch();
}

int CExpression::GetValue(double& fvalue)
{
	code=0;
	if(m_pbranch == NULL) return -1;
	fvalue=vexp(m_pbranch);
	return code;
}

BranchPtr CExpression::GetBranch()
{
	return m_pbranch;
}

BranchPtr CExpression::CloneBranch()
{
	return clone(m_pbranch);	
}

double CExpression::vexp(BranchPtr branch)
{
	double v;
	if(branch->operation==NULL) {code=10;return 0;}
	switch(branch->operation)
	{
	case '+': return(vexp(branch->left)+vexp(branch->right));
	case '-': return(vexp(branch->left)-vexp(branch->right));
	case '*': return(vexp(branch->left)*vexp(branch->right));
	case '/': 
		{
			v=vexp(branch->right);
			if(v==0)
			{code=DIVISION_BY_0;return -vexp(branch->left)/0.001;}
			else
				return(vexp(branch->left)/v);
		}
	case 150 : return(sin(vexp(branch->left)));
	case 151 : return(cos(vexp(branch->left)));
	case 152 : return(exp(vexp(branch->left)));
	case 153 : 
		{
			v=vexp(branch->left) ;
			if(v<0) {code=INVALID_DOMAIN;return 0;}
			else return(sqrt(v));
		}
	case 154 : 
		{
			v=vexp(branch->left) ;
			if(v<=0) {code=INVALID_DOMAIN; return 0;}
			else return(log(v));
		}
	case 155 : return (tan (vexp(branch->left)));
	case 156 : return (1 / tan (vexp(branch->left)));
	case 157 : return (asin (vexp(branch->left)));
	case 158 : return (acos (vexp(branch->left)));
	case 159 : return (atan (vexp(branch->left)));
	case 160 : return (int(vexp(branch->left)));
	case 161 : return (fabs(vexp(branch->left)));
	//return (vexp(branch->left)<=vexp(branch->right)?vexp(branch->left):vexp(branch->right));
	case 162 :
		{
			if(vexp(branch->left)<=vexp(branch->right)) return (vexp(branch->left));
			else return (vexp(branch->right));
		}
	case 163 : return (vexp(branch->left)<=vexp(branch->right));
	case 164 : return (vexp(branch->left)>=vexp(branch->right));
	case 165 : return (vexp(branch->left)!=vexp(branch->right));
	case 166 : return (vexp(branch->left)==vexp(branch->right));
	case 167 :
		{
			v=vexp(branch->left) ;
			if(v<=0) {code=INVALID_DOMAIN;return 0;}
			else return(log(v)/log(2.0));
		}
	case 168 :
		{
			if(vexp(branch->left)>=vexp(branch->right)) return (vexp(branch->left));
			else  return (vexp(branch->right));
		}
	case 169 : return(vexp(branch->left)?vexp(branch->right->left):vexp(branch->right->right));
	case '|' : return(fabs(vexp(branch->left)));
	case '^' : return(pow(vexp(branch->left),vexp(branch->right)));
	case '@' : return (branch->fvalue);
	//logical operations evaluation
	case '<' : return( vexp(branch->left)<vexp(branch->right) );
	case '>' : return( vexp(branch->left)>vexp(branch->right) );
	//case '=' : return( vexp(branch->left)==vexp(branch->right) );
	case '!' : return(!vexp(branch->right)) ;
	case '&' : return(vexp(branch->left)&&vexp(branch->right));
	case '#' : return(vexp(branch->left)||vexp(branch->right));	 

	default : 
		{
			if(m_pvariable==NULL) 
			{
				code=UNDEFINED_VARIABLE;
				return 0;
			}
			CValue *fvalue;
			if(!m_pvariable->Lookup(*branch->svalue,fvalue))
			{
				code=UNDEFINED_VARIABLE;
				return 0;
			}
			else return fvalue->GetValue();
		}
	}
}

void CExpression::trim()
{
	while (m_definitie[pozitie]==' ' && m_definitie[pozitie]!='\0')
		pozitie ++;
}

BranchPtr CExpression::addcut()
{
	BranchPtr branch;
	BranchPtr branch_1 = multdivision();
	BranchPtr branch_2;
	if(branch_1 == NULL) return NULL;  // In caz de eroare terminate
	while ((m_definitie[pozitie]=='-') || (m_definitie[pozitie]=='+')) 
	{
		branch=new Branch;
		branch->left = branch_1;
		branch->operation=m_definitie[pozitie];
		pozitie++;
		branch_2 = multdivision();
		branch->right=branch_2;
		if(branch_2 == NULL) 
		{
			release(branch);
			return NULL;  // In caz de eroare terminate
		}
		branch_1 = branch;
	}

	return branch_1;
}

BranchPtr CExpression::multdivision()
{
	BranchPtr branch;
	BranchPtr branch_1 = power();
	BranchPtr branch_2;
	if(branch_1 == NULL) return NULL;  // In caz de eroare terminate

	while ((m_definitie[pozitie]=='*') || (m_definitie[pozitie]=='/')) 
	{
		branch=new Branch;
		branch->left=branch_1;
		branch->operation=m_definitie[pozitie];
		pozitie++;
		branch_2 = power();
		branch->right=branch_2;
		if(branch_2 == NULL) 
		{
			release(branch);
			return NULL;  // In caz de eroare terminate
		}
		branch_1 = branch;
	}
	return branch_1;
}

BranchPtr CExpression::power()
{
	BranchPtr branch = NULL;
	BranchPtr branch_1 = logical();
	BranchPtr branch_2;
	if(branch_1 == NULL) return NULL;  // In caz de eroare terminate

	while (m_definitie[pozitie]=='^') 
	{
		branch=new Branch;
		branch->left=branch_1;
		branch->operation=m_definitie[pozitie];
		pozitie++;
		branch_2 = logical();
		branch->right=branch_2;
		if(branch_2 == NULL) 
		{
			release(branch);
			return NULL;  // In caz de eroare terminate
		}
		branch_1 = branch;
	}
	return branch_1;
}

BranchPtr CExpression::logical()
{
	BranchPtr branch;
	BranchPtr branch_1 = other();
	BranchPtr branch_2;
	if(branch_1 == NULL) return NULL;  // In caz de eroare terminate

	while((m_definitie[pozitie]=='<') || (m_definitie[pozitie]=='>')
		||(m_definitie[pozitie]=='=')
		||(m_definitie[pozitie]=='&')
		||(m_definitie[pozitie]=='#')/* || another same priority operations*/) 
	{
		if((m_definitie[pozitie]=='<')&&(m_definitie[pozitie+1]=='='))
		{	
			branch=new Branch;
			branch->left=branch_1;
			branch->operation=163;
			pozitie++;
			pozitie++;
			branch_2 = other();
			branch->right=branch_2;
			if(branch_2 == NULL) 
			{
				release(branch);
				return NULL;  // In caz de eroare terminate
			}

			branch_1 = branch;
		}
		else if((m_definitie[pozitie]=='>')&&(m_definitie[pozitie+1]=='='))
		{	
			branch=new Branch;
			branch->left=branch_1;
			branch->operation=164;
			pozitie++;
			pozitie++;
			branch_2 = other();
			branch->right=branch_2;
			if(branch_2 == NULL) 
			{
				release(branch);
				return NULL;  // In caz de eroare terminate
			}

			branch_1 = branch;
		}
		else if((m_definitie[pozitie]=='<')&&(m_definitie[pozitie+1]=='>'))
		{	
			branch=new Branch;
			branch->left=branch_1;
			branch->operation=165;
			pozitie++;
			pozitie++;
			branch_2 = other();
			branch->right=branch_2;
			if(branch_2 == NULL) 
			{
				release(branch);
				return NULL;  // In caz de eroare terminate
			}

			branch_1 = branch;
		}
		else if((m_definitie[pozitie]=='=')&&(m_definitie[pozitie+1]=='='))
		{	
			branch=new Branch;
			branch->left=branch_1;
			branch->operation=166;
			pozitie++;
			pozitie++;
			branch_2 = other();
			branch->right=branch_2;
			if(branch_2 == NULL) 
			{
				release(branch);
				return NULL;  // In caz de eroare terminate
			}

			branch_1 = branch;
		}
		else
		{
			branch=new Branch;
			branch->left=branch_1;
			branch->operation=m_definitie[pozitie];
			pozitie++;
			branch_2 = other();
			branch->right=branch_2;
			if(branch_2 == NULL) 
			{
				release(branch);
				return NULL;  // In caz de eroare terminate
			}

			branch_1 = branch;
		}
	}
	return branch_1;
}

BranchPtr CExpression::other()
{
	BranchPtr branch = NULL;
	BranchPtr branch_2;
	if((m_definitie[pozitie]=='!') /* || another same priority operations*/) 
	{
		branch=new Branch;
		branch->left=NULL;
		branch->operation=m_definitie[pozitie];
		pozitie++;
		branch_2 = other();
		branch->right=branch_2;
		if(branch_2 == NULL) 
		{
			release(branch);
			return NULL;
		}
	}
	else branch = separate();

	return branch;
}

BranchPtr CExpression::separate()
{
	BranchPtr branch = NULL, branch_2 = NULL, left = NULL;
	while(m_definitie[pozitie] == ' ' && m_definitie[pozitie] != '\0')
		pozitie++;

	if(m_definitie[pozitie]=='-')
	{
		branch = new Branch;
		left = new Branch;
		left->right=NULL;
		left->left=NULL;
		left->operation='@';
		left->fvalue=-1;
		branch->left=left;
		branch->operation='*';
		pozitie++;
		branch->right = addcut();
		if(branch->right == NULL) return NULL;
		return branch;   
	}
	if((m_definitie[pozitie]=='(')||(m_definitie[pozitie]==','))
	{
		pozitie++;
		branch = addcut();
		if(branch == NULL) return NULL;
		if((m_definitie[pozitie]!=')')&&(m_definitie[pozitie]!=','))
		{
			release(branch);
			return NULL;
		}

		pozitie++;
		return branch;
	}
	else if(m_definitie[pozitie]=='|')
	{
		pozitie++;
		branch_2 = addcut();
		if(branch_2 == NULL) return NULL;
		if(m_definitie[pozitie]!='|')
		{
			release(branch);
			return NULL;
		}
		branch = new Branch;
		branch->left=branch_2;
		branch->right=NULL;
		branch->operation='|';
		pozitie++;
		return branch;
	}
	else return identifier();
	return branch;
}

BranchPtr CExpression::identifier()
{
	int poz;
	BranchPtr branch = NULL,branch_2 = NULL,branch_1 = NULL;
	BranchPtr result = NULL;
	poz=pozitie;
	trim();
	if(m_definitie[pozitie]=='\0') result  = NULL;
	if(isdigit(m_definitie[pozitie]))	// Este numar ?
	{
		while  ((isdigit(m_definitie[pozitie]) || (m_definitie[pozitie]=='.')))
			pozitie++;
		branch = new Branch;
		branch->left = NULL; 
		branch->right = NULL;
		branch->operation = '@';
		branch->fvalue = _tstof(m_definitie.Mid(poz,pozitie-poz));
		result = branch;
	}
	if(isalpha(m_definitie[pozitie]))	// Am i an identifier ?
	{
		while  (isalnum(m_definitie[pozitie])) 
			pozitie++;

		CString id = m_definitie.Mid(poz,pozitie-poz);
		CString nid = id;
		//id.MakeUpper();
		id.MakeLower();

		if(id == "sin")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=150;
			trim();
			return branch;
		}
		else if(id == "cos")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=151;
			trim();
			return branch;
		}
		else if(id == "exp")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=152;
			trim();
			return branch;
		}
		else if(id == "sqrt")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=153;
			trim();
			return  branch;
		}
		else if(id == "ln")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=154;
			trim();
			return branch;
		}
		else if(id == "tg")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=155;
			trim();
			return branch;
		}
		else if(id == "ctg")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=156;
			trim();
			return branch;
		}
		else if(id == "asin")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=157;
			trim();
			return branch;
		}
		else if(id == "acos")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=158;
			trim();
			return branch;
		}
		else if(id == "atg")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=159;
			trim();
			return branch;
		}
		else if(id == "int")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=160;
			trim();
			return branch;
		}
		else if(id == "abs")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=161;
			trim();
			return branch;
		}
		else if(id == "min")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			pozitie--;
			branch_2 = separate();
			branch->right = branch_2;
			branch->operation=162;
			trim();
			return branch;
		}
		else if(id == "log")		// Functia sinus CString
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			branch->right=NULL;
			branch->operation=167;
			trim();
			return branch;
		}
		else if(id == "max")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			pozitie--;
			branch_2 = separate();
			branch->right = branch_2;
			branch->operation=168;
			trim();
			return branch;
		}
		else if(id == "if")
		{
			branch_2 = separate();
			branch = new Branch;
			branch->left = branch_2;
			pozitie--;
			branch_2 = separate();
			pozitie--;
			branch_1 = new Branch;
			branch_1->left = branch_2;
			branch_2 = separate();
			branch_1->right = branch_2;
			branch->right=branch_1;
			branch->operation=169;
			trim();
			return branch;
		}

		CValue *fvalue;
		if(m_pvariable->Lookup(nid,fvalue))
		{
			branch = new Branch;
			branch -> left = NULL;
			branch -> right = NULL;
			branch -> operation = '`';
			branch -> svalue = new CString(nid); 
			result = branch;
		}
		else result = NULL;
	}
	trim();
	return result;

}

void CExpression::release(BranchPtr branch)
{
	if(branch==NULL) return;
	if(branch->left!=NULL) release(branch->left);
	if(branch->right!=NULL) release(branch->right);
	if(branch->operation == '`')
		delete branch->svalue;
	delete branch;
}

BranchPtr CExpression::clone(BranchPtr branch)
{
	if(branch == NULL)
		return NULL;
	BranchPtr clonBranch = new Branch;
	*clonBranch = *branch;
	clonBranch->left = clone(branch->left);
	clonBranch->right = clone(branch->right);
	return clonBranch;
}