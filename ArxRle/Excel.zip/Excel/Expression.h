#define DIVISION_BY_0 1
#define ILEGAL_OPERATION 2
#define UNDEFINED_VARIABLE 3
#define INVALID_DOMAIN 4

class CValue : public CObject
{
public:
	CValue() {m_value = NULL;}
	virtual ~CValue() {delete m_value;}

	virtual void SetValue(void* value) {m_value = value;}
	virtual double GetValue() {return 0;}
	virtual void UpdateValue() {}
	virtual void Serialize(CArchive &ar) {}

protected:
	void *m_value;
};
typedef CTypedPtrMap<CMapStringToOb,CString,CValue*> CMapVariable;

struct Branch
{
	struct Branch *left,*right;
	unsigned char operation; 
	union {double fvalue; CString *svalue;};
};
typedef Branch* BranchPtr;

class CExpression: public CObject
{
public:
	CExpression();
	CExpression(CMapVariable* vars);
	virtual ~CExpression();
	CExpression &operator=(CExpression& expr);
	CExpression(CExpression& expr);
	void AtachVariables(CMapVariable* vars);

	virtual void Serialize(CArchive& branch);		// The serialization function
	int UpdateBranch();		                    // Update the tree
	int ChangeExpression(CString& expresie);	// Change expression
	int GetValue(double& fvalue);	                // gets the value of the expression
	BranchPtr GetBranch();
	BranchPtr CloneBranch();


private:
	CMapVariable* m_pvariable;      // pointer to value table
	CString m_definitie;			// the expression in string
	BranchPtr m_pbranch;		    // the expresion as a binary tree
	int pozitie;					// string parsing variable
	int code;
	
	double vexp(BranchPtr branch);
	void trim();
	BranchPtr addcut();             // + -
	BranchPtr multdivision();       // * /
	BranchPtr power();              // ^
	BranchPtr logical();            // < > = & #
	BranchPtr other();              // !
	BranchPtr separate();			// ( , | ) @
	BranchPtr identifier();         // sin cos exp sqrt ln tg ctg asin acos atg int abs min max if for log 

	void release(BranchPtr branch);
	BranchPtr clone(BranchPtr branch);
};