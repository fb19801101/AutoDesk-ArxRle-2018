//
//  MODULE: Ado.h
//
//	AUTHOR: Carlos Antollini 
//
//  mailto: cantollini@hotmail.com
//
//	Date: 07/25/2002
//
//	Version 2.04
// 

#ifndef _ADO_H_
#define _ADO_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include <afx.h>
#include <afxdisp.h>
#include <math.h>

//����ACCES ADO���ݿ�
#pragma warning (default: 4146)
#import "C:/Program Files (x86)/Common Files/System/ado/msadox.dll" rename_namespace("ADOX") \
	rename ("EOS", "_EOS") \
	rename ("EOF", "_EOF") \
	rename ("BOF", "_BOF") \
	rename ("Error", "_Error") \
	rename ("Field", "_Field") \
	rename ("LockTypeEnum", "_LockTypeEnum") \
	rename ("DataTypeEnum", "_DataTypeEnum") \
	rename ("FieldAttributeEnum", "_FieldAttributeEnum") \
	rename ("EditModeEnum", "_EditModeEnum") \
	rename ("RecordStatusEnum", "_RecordStatusEnum") \
	rename ("ParameterDirectionEnum", "_ParameterDirectionEnum")

#import "C:/Program Files (x86)/Common Files/System/ado/msado15.dll" \
	no_namespace \
	rename ("EOS", "_EOS") \
	rename ("EOF", "_EOF") \
	rename ("BOF", "_BOF") \
	rename ("Error", "_Error") \
	rename ("Field", "_Field") \
	rename ("LockTypeEnum", "_LockTypeEnum") \
	rename ("DataTypeEnum", "_DataTypeEnum") \
	rename ("FieldAttributeEnum", "_FieldAttributeEnum") \
	rename ("EditModeEnum", "_EditModeEnum") \
	rename ("RecordStatusEnum", "_RecordStatusEnum") \
	rename ("ParameterDirectionEnum", "_ParameterDirectionEnum")

#include "icrsint.h"
#pragma warning (default:4146)

class CADOConnection;
class CADOCatalog;
class CADORecordset;
class CADOParameter;
class CADOCommand;

struct Stru_AdoFieldInfo
{
	char m_strName[30]; 
	short m_nType;
	long m_lSize; 
	long m_lDefinedSize;
	long m_lAttributes;
	short m_nOrdinalPosition;
	BOOL m_bRequired;   
	BOOL m_bAllowZeroLength; 
	long m_lCollatingOrder;  
};

CString IntToStr(int nVal);

CString LongToStr(long lVal);

CString ULongToStr(unsigned long ulVal);

CString DblToStr(double dblVal, int ndigits = 20);

CString DblToStr(float fltVal);

enum Enum_AdoDataType
{
	adoEmpty = adEmpty,                         // 0 û��ֵ (DBTYPE_EMPTY)��
	adoSmallInt = adSmallInt,                   // 2 һ��˫�ֽڵ��з������� (DBTYPE_I2)��
	adoInteger = adInteger,                     // 3 һ�����ֽڵ��з������� (DBTYPE_I4)��
	adoSingle = adSingle,                       // 4 һ�������ȸ���ֵ (DBTYPE_R4)��
	adoDouble = adDouble,                       // 5 һ��˫���ȸ���ֵ (DBTYPE_R8)��
	adoCurrency = adCurrency,                   // 6 һ������ֵ (DBTYPE_CY)��������һ���������֣�С�����Ҳ�����λ���֡���ֵ�洢Ϊ���ֽڡ���ΧΪ 10,000 ���з���������
	adoDate = adDate,                           // 7 ����ֵ (DBTYPE_DATE)�����ڱ���Ϊ˫�����������ֵ����������Ǵ� 1899 �� 12 �� 30 �������������С��������һ�쵱�е�Ƭ��ʱ�䡣
	adoBSTR = adBSTR,                           // 8 �� Null ��ֹ���ַ��� (Unicode) (DBTYPE_BSTR)��
	adoIDispatch = adIDispatch,                 // 9  ָ�� COM ������ IDispatch �ӿڵ�ָ�� (DBTYPE_IDISPATCH)��ע��:ADO Ŀǰ��֧�������������͡�ʹ�������ܵ��²���Ԥ�ϵĽ����
	adoError = adError,                         // 10 һ�� 32 λ�Ĵ������ (DBTYPE_ERROR)��
	adoBoolean = adBoolean,                     // 11 һ������ֵ (DBTYPE_BOOL)��
	adoVariant = adVariant,                     // 12  һ�� Automation Variant (DBTYPE_VARIANT)��ע��:ADO Ŀǰ��֧�������������͡�ʹ�������ܵ��²���Ԥ�ϵĽ����
	adoIUnknown = adIUnknown,                   // 13  ָ�� COM ������ IUnknown �ӿڵ�ָ�� (DBTYPE_IUNKNOWN)��ע��:ADO Ŀǰ��֧�������������͡�ʹ�������ܵ��²���Ԥ�ϵĽ����
	adoDecimal = adDecimal,                     // 14 ���й̶����Ⱥͷ�Χ��ȷ������ֵ (DBTYPE_DECIMAL)��
	adoTinyInt = adTinyInt,                     // 16 һ�����ֽڵ��з������� (DBTYPE_I1)��
	adoUnsignedTinyInt = adUnsignedTinyInt,     // 17 һ�����ֽڵ��޷������� (DBTYPE_UI1)��
	adoUnsignedSmallInt = adUnsignedSmallInt,   // 18 һ��˫�ֽڵ��޷������� (DBTYPE_UI2)��
	adoUnsignedInt = adUnsignedInt,             // 19 һ�����ֽڵ��޷������� (DBTYPE_UI4)��
	adoBigInt = adBigInt,                       // 20 һ�����ֽڵ��з������� (DBTYPE_I8)��
	adoUnsignedBigInt = adUnsignedBigInt,       // 21 һ�����ֽڵ��޷������� (DBTYPE_UI8)��
	adoFileTime = adFileTime,                   // 64 һ�� 64 λ��ֵ����ʾ�� 1601 �� 1 �� 1 �տ�ʼ�� 100 ��ʮ�ڷ�֮һ���������� (DBTYPE_FILETIME)��
	adoGUID = adGUID,                           // 72 ȫ��Ψһ��ʶ�� (GUID) (DBTYPE_GUID)��
	adoBinary = adBinary,                       // 128 һ��������ֵ (DBTYPE_BYTES)��
	adoChar = adChar,                           // 129 һ���ַ���ֵ (DBTYPE_STR)��
	adoWChar = adWChar,                         // 130 һ���� Null ��ֹ�� Unicode �ַ��� (DBTYPE_WSTR)��
	adoNumeric = adNumeric,                     // 131 ���й̶����Ⱥͷ�Χ��ȷ������ֵ (DBTYPE_NUMERIC)��
	adoUserDefined = adUserDefined,             // 132 һ���û�����ı��� (DBTYPE_UDT)��
	adoDBDate = adDBDate,                       // 133 ����ֵ (yyyymmdd) (DBTYPE_DBDATE)��
	adoDBTime = adDBTime,                       // 134 ʱ��ֵ (hhmmss) (DBTYPE_DBTIME)��
	adoDBTimeStamp = adDBTimeStamp,             // 135 ����/ʱ�����yyyymmddhhmmss ��ʮ�ڷ�֮һ��С����(DBTYPE_DBTIMESTAMP)��
	adoChapter = adChapter,                     // 136 һ�����ֽڵ��Ӽ�ֵ����ʶ���м����е��� (DBTYPE_HCHAPTER)��
	adoPropVariant = adPropVariant,             // 138 һ�� Automation PROPVARIANT (DBTYPE_PROP_VARIANT)��
	adoVarNumeric = adVarNumeric,               // 139 һ������ֵ�������� Parameter ���󣩡�
	adoVarChar = adVarChar,                     // 200 һ���ַ���ֵ�������� Parameter ���󣩡�
	adoLongVarChar = adLongVarChar,             // 201 һ�����ַ���ֵ�������� Parameter ���󣩡�
	adoVarWChar = adVarWChar,                   // 202 һ���� Null ��ֹ�� Unicode �ַ����������� Parameter ���󣩡�
	adoLongVarWChar = adLongVarWChar,           // 203 һ���� Null ��ֹ�ĳ� Unicode �ַ���ֵ�������� Parameter ���󣩡�
	adoVarBinary = adVarBinary,                 // 204 һ��������ֵ�������� Parameter ���󣩡�
	adoLongVarBinary = adLongVarBinary,         // 205 һ����������ֵ�������� Parameter ���󣩡�
	adoArray = adArray                          // 0x2000 һ����־ֵ��ͨ������һ���������ͳ�����ϣ�ָʾ���������͵����顣
};

class CADOData
{
public:
	CADOData();
	CADOData(const long r1, const long r2, const int c1, const int c2);
	CADOData(_variant_t**& src, const long r1, const long r2, const int c1, const int c2);
	CADOData(_variant_t**& src, const long r1, const long r2, const int c1, const int c2, _variant_t*& sum);
	CADOData(_variant_t*& src, const long r1, const int c1);
	CADOData& operator=(const CADOData& src);

	void Release();
	bool IsNull();

public:
	void* vals[3];
	long rows, row1, row2;
	int cols, col1, col2;
};

class CADOConnection
{
public:
	enum Enum_AdoConnectionOption
	{
		adoConModeUnknown = adModeUnknown,
		adoConModeRead = adModeRead,
		adoConModeWrite = adModeWrite,
		adoConModeReadWrite = adModeReadWrite,
		adoConModeShareDenyRead = adModeShareDenyRead,
		adoConModeShareDenyWrite = adModeShareDenyWrite,
		adoConModeShareExclusive = adModeShareExclusive,
		adoConModeShareDenyNone = adModeShareDenyNone
	};

	CADOConnection()
	{
		::CoInitialize(NULL);

		m_pConnection = NULL;
		m_strConnection = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_nRecordsAffected = 0;
	}
	CADOConnection(_ConnectionPtr& con);
	CADOConnection(CADOConnection& adoCon);
	CADOConnection& operator=(_ConnectionPtr& con);
	CADOConnection& operator=(CADOConnection& adoCon);

	~CADOConnection()
	{
		if(m_pConnection) m_pConnection.Release();
		m_pConnection = NULL;
		m_strConnection = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;

		::CoUninitialize();
	}

	BOOL Open(CString strConnection = _T(""), CString strUserID = _T(""), CString strPassword = _T(""), Enum_AdoConnectionOption enuOption = adoConModeUnknown);
	_ConnectionPtr GetConnection() { return m_pConnection; };
	operator _ConnectionPtr() { return m_pConnection; };
	int Execute(CString strExec);
	int GetRecordsAffected() const { return m_nRecordsAffected; };
	DWORD GetRecordCount(_RecordsetPtr pRs);
	long BeginTransaction() const { return m_pConnection->BeginTrans(); };
	long CommitTransaction() const { return m_pConnection->CommitTrans(); };
	long RollbackTransaction() const { return m_pConnection->RollbackTrans(); };
	BOOL IsOpen();
	void Close();
	void SetConnectionString(CString strConnection) { m_strConnection = strConnection; };
	CString GetConnectionString() const { return m_strConnection; };
	CString GetLastErrorString() const { return m_strLastError; };
	DWORD GetLastError() const { return m_dwLastError; };

protected:
	void dump_com_error(_com_error &e);

protected:
	_ConnectionPtr m_pConnection;
	CString m_strConnection;
	CString m_strLastError;
	DWORD m_dwLastError;
	int m_nRecordsAffected;
};

class CADOCatalog
{
public:
	CADOCatalog()
	{
		::CoInitialize(NULL);

		m_pCatalog = NULL;
		m_strCatalog = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
		m_pCatalog.CreateInstance(__uuidof(ADOX::Catalog));
	}

	~CADOCatalog()
	{
		if(m_pCatalog) m_pCatalog.Release();

		m_pCatalog = NULL;
		m_strCatalog = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;

		::CoUninitialize();
	}

	CADOCatalog(ADOX::_CatalogPtr& cat);
	CADOCatalog(CADOCatalog& adoCat);
	CADOCatalog& operator=(ADOX::_CatalogPtr& cat);
	CADOCatalog& operator=(CADOCatalog& adoCat);

	BOOL Create(CString strCatalog = _T(""));
	ADOX::_CatalogPtr GetCatalog() { return m_pCatalog; };
	operator ADOX::_CatalogPtr()  { return m_pCatalog; };
	void SetCatalogString(CString strCatalog) { m_strCatalog = strCatalog; };
	CString GetCatalogString() const { return m_strCatalog; };
	CString GetLastErrorString() const { return m_strLastError; };
	DWORD GetLastError() const { return m_dwLastError; };

protected:
	void dump_com_error(_com_error &e);

protected:
	ADOX::_CatalogPtr m_pCatalog;
	CString m_strCatalog;
	CString m_strLastError;
	DWORD m_dwLastError;
};

class CADODatabase
{
public:
	enum Enum_AdoDriver
	{
		adoAccess = 0,
		adoExcel = 1,
		adoText = 2,
		adoMYSQL = 3,
		adoMSSQL = 4
	};

	CADODatabase()
	{
		m_enuDataDriver = adoMSSQL;
		m_strDataPath = _T("");
		m_strDataBase = _T("");
		m_strUId = _T("");
		m_strPwd = _T("");
		m_strServer = _T("");
	}

	~CADODatabase()
	{
		m_enuDataDriver = adoMSSQL;
		m_strDataPath = _T("");
		m_strDataBase = _T("");
		m_strUId = _T("");
		m_strPwd = _T("");
		m_strServer = _T("");
	}

	Enum_AdoDriver GetDataDriver() const { return m_enuDataDriver; }
	void SetDataDriver(Enum_AdoDriver enu) { m_enuDataDriver = enu; }

	CString GetDataPath() const { return m_strDataPath; }
	void SetDataPath(CString str) { m_strDataPath = str; }

	CString GetDataBase() const { return m_strDataBase; }
	void SetDataBase(CString str) { m_strDataBase = str; }

	CString GetUId() const { return m_strUId; }
	void SetUId(CString str) { m_strUId = str; }

	CString GetPwd() const { return m_strPwd; }
	void SetPwd(CString str) { m_strPwd = str; }

	CString GetServer() const { return m_strServer; }
	void SetServer(CString str) { m_strServer = str; }

	BOOL OpenConnection();
	BOOL CreateCatalog();
	BOOL Execute(CString strExec);
	void CloseConnection();
	CString GetConString() const;

	void SetFieldProperty(CString tbl, int col1, int col2);
	CString GetFields(CString tbl, int col1, int col2);
	int GetFields(CString tbl, int col1, int col2, CString*& fids);
	CString _GetFields(CString tbl, int idx, int* cols);
	void _GetFields(CString tbl, int idx, int* cols, CString*& fids);
	void SetProceduresSql(CString tbl, CString sql);
	void SetViewSql(CString tbl, CString sql);
	void SetQuery(CString tbl, char* s1, char* s2);
	long GetRecordCount(CString tbl);
	long AddRecord(CString tbl, CString fids, CString vals);
	long AddRecord(CString tbl, int idxs, CString*& fids, CADOData& data);
	long AddRecord(CString tbl, long rows, int idxs, CString*& fids, CADOData& data);
	void SetRecord(CString tbl, long id, CString fidvals);
	void SetRecord(CString tbl, long id, int idxs, CString*& fids, CADOData& data);
	void SetRecord(CString tbl, long id1, long id2, int idxs, CString*& fids, CADOData& data);
	void ReSetID(CString tbl);
	void GetRecord(CADOData& data, CString tbl, long id, CString fids = _T("*"));
	void GetRecord(CADOData& data, CString tbl, long id1, long id2, CString fids = _T("*"));
	void GetRecord(CADORecordset& data, CString tbl, CString fid, CADOData& vals);
	void _GetRecord(CADOData& data, CString tbl, long id1, long id2, CString fids = _T("*"));
	void SumRecord(CADOData& data, CString tbl, int idx, CString*& fids);
	void FindRecord(CADOData& data, CString tbl, CString strFind, int nSearchDirection = 1);
	void DelRecord(CString tbl, long id);
	void DelRecord(CString tbl, long id1, long id2);

	CADOConnection& GetConnection() {return m_adoConnection;}
	CADOCatalog& GetCatalog() {return m_adoCatalog;}

protected:
	CADOConnection m_adoConnection;
	CADOCatalog m_adoCatalog;

	Enum_AdoDriver m_enuDataDriver;
	CString m_strDataPath;
	CString m_strDataBase;
	CString m_strUId;
	CString m_strPwd;
	CString m_strServer;
};

class CADORecordset
{
public:
	enum Enum_AdoRecordsetOpen
	{
		adoRstUnknown = 0,
		adoRstQuery = 1,
		adoRstTable = 2,
		adoRstStoredProc = 3,
	};

	enum Enum_AdoRecordsetEdit
	{
		adoRstNone = 0,
		adoRstNew = 1,
		adoRstEdit = 2
	};
	
	enum Enum_AdoRecordsetPosition
	{
		adoRstNOF = -1,
		adoRstBOF = -2,
		adoRstEOF = -3
	};
	
	enum Enum_AdoRecordsetSearch
	{	
		adoRstForward = 1,
		adoRstBackward = -1
	};


	CADORecordset()
	{
		m_pRecordset = NULL;
		m_strQuery = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
		m_pRecBinding = NULL;
		m_pRecordset.CreateInstance(__uuidof(Recordset));
		m_pRecordset->CursorType = adOpenKeyset;
		m_pRecordset->LockType = adLockOptimistic;
		m_pRecordset->CursorLocation = adUseClient;
		m_nEditStatus = adoRstNone;
		m_nSearchDirection = adoRstForward;
	}
	CADORecordset(_ConnectionPtr& pConnection);
	CADORecordset(CADOConnection& adoConnection);
	CADORecordset(_RecordsetPtr& rst);
	CADORecordset(CADORecordset& adoRst);
	CADORecordset& operator=(_RecordsetPtr& rst);
	CADORecordset& operator=(CADORecordset& adoRst);

	~CADORecordset()
	{
		if(m_pRecordset) m_pRecordset.Release();
		m_pRecordset = NULL;
		m_pRecBinding = NULL;
		m_strQuery = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
		m_nEditStatus = adoRstNone;
	}

	BOOL SetFieldValue(int nIndex, int nValue);
	BOOL SetFieldValue(CString strFieldName, int nValue);
	BOOL SetFieldValue(int nIndex, long lValue);
	BOOL SetFieldValue(CString strFieldName, long lValue);
	BOOL SetFieldValue(int nIndex, unsigned long ulValue);
	BOOL SetFieldValue(CString strFieldName, unsigned long ulValue);
	BOOL SetFieldValue(int nIndex, long long llValue);
	BOOL SetFieldValue(CString strFieldName, long long llValue);
	BOOL SetFieldValue(int nIndex, double dblValue);
	BOOL SetFieldValue(CString strFieldName, double dblValue);
	BOOL SetFieldValue(int nIndex, CString strValue);
	BOOL SetFieldValue(CString strFieldName, CString strValue);
	BOOL SetFieldValue(int nIndex, COleDateTime time);
	BOOL SetFieldValue(CString strFieldName, COleDateTime time);
	BOOL SetFieldValue(int nIndex, bool bValue);
	BOOL SetFieldValue(CString strFieldName, bool bValue);
	BOOL SetFieldValue(int nIndex, COleCurrency cyValue);
	BOOL SetFieldValue(CString strFieldName, COleCurrency cyValue);
	BOOL SetFieldValue(int nIndex, COleVariant vtValue);
	BOOL SetFieldValue(CString strFieldName, COleVariant vtValue);
	BOOL SetFieldValue(int nIndex, _variant_t vtValue);
	BOOL SetFieldValue(CString strFieldName, _variant_t vtValue);

	BOOL SetFieldEmpty(int nIndex);
	BOOL SetFieldEmpty(CString strFieldName);

	void CancelUpdate();
	BOOL Update();
	void Edit();
	BOOL AddNew();
	BOOL AddNew(CADORecordBinding &pAdoRecordBinding);

	BOOL Find(CString strFind, int nSearchDirection = adoRstForward);
	BOOL FindFirst(CString strFind);
	BOOL FindNext();
	
	int GetEditStatus() { return m_nEditStatus; }

	CString GetQuery() {return m_strQuery;};
	void SetQuery(CString strQuery) {m_strQuery = strQuery;};
	BOOL RecordBinding(CADORecordBinding &pAdoRecordBinding);
	DWORD GetRecordCount();
	BOOL IsOpen();
	void Close();
	BOOL Open(_ConnectionPtr pConnection, CString strExec = _T(""), int nOption = adoRstUnknown);
	BOOL Open(CString strExec = _T(""), int nOption = adoRstUnknown);
	long GetFieldCount() {return m_pRecordset->Fields->GetCount();}
	VARTYPE GetVarType(CString strFieldName) {_variant_t vtValue; GetFieldValue(strFieldName, vtValue);return vtValue.vt;}
	VARTYPE GetVarType(int nIndex) {_variant_t vtValue; GetFieldValue(nIndex, vtValue);return vtValue.vt;}
	BOOL GetFieldValue(CString strFieldName, int& nValue);
	BOOL GetFieldValue(int nIndex, int& nValue);
	BOOL GetFieldValue(CString strFieldName, long& lValue);
	BOOL GetFieldValue(int nIndex, long& lValue);
	BOOL GetFieldValue(CString strFieldName, unsigned long& ulValue);
	BOOL GetFieldValue(int nIndex, unsigned long& ulValue);
	BOOL GetFieldValue(CString strFieldName, long long& llValue);
	BOOL GetFieldValue(int nIndex, long long& llValue);
	BOOL GetFieldValue(CString strFieldName, double& dbValue);
	BOOL GetFieldValue(int nIndex, double& dbValue);
	BOOL GetFieldValue(CString strFieldName, CString& strValue, CString strDateFormat = _T(""));
	BOOL GetFieldValue(int nIndex, CString& strValue, CString strDateFormat = _T(""));
	BOOL GetFieldValue(CString strFieldName, COleDateTime& time);
	BOOL GetFieldValue(int nIndex, COleDateTime& time);
	BOOL GetFieldValue(CString strFieldName, bool& bValue);
	BOOL GetFieldValue(int nIndex, bool& bValue);
	BOOL GetFieldValue(CString strFieldName, COleCurrency& cyValue);
	BOOL GetFieldValue(int nIndex, COleCurrency& cyValue);
	BOOL GetFieldValue(CString strFieldName, COleVariant& vtValue);
	BOOL GetFieldValue(int nIndex, COleVariant& vtValue);
	BOOL GetFieldValue(CString strFieldName, _variant_t& vtValue);
	BOOL GetFieldValue(int nIndex, _variant_t& vtValue);
	
	BOOL IsFieldNull(CString strFieldName);
	BOOL IsFieldNull(int nIndex);
	BOOL IsFieldEmpty(CString strFieldName);
	BOOL IsFieldEmpty(int nIndex);	
	BOOL IsEOF() {return m_pRecordset->_EOF == VARIANT_TRUE;};
	BOOL IsBOF() {return m_pRecordset->_BOF == VARIANT_TRUE;};
	void MoveFirst() {m_pRecordset->MoveFirst();};
	void MoveNext() {m_pRecordset->MoveNext();};
	void MovePrevious() {m_pRecordset->MovePrevious();};
	void MoveLast() {m_pRecordset->MoveLast();};

	BOOL Skip(ULONG nSkip = 1)
	{
		_variant_t vtValue; vtValue.vt = VT_I4;
		vtValue.lVal = (ULONG)adBookmarkCurrent;
		return m_pRecordset->Move(nSkip,vtValue) == S_OK;
	};

	BOOL GotoRecord(ULONG nRecno)
	{
		_variant_t vtValue;
		vtValue.vt = VT_I4;
		vtValue.lVal = (ULONG)adBookmarkFirst;
		return m_pRecordset->Move(nRecno,vtValue) == S_OK;
	};

	long GetAbsolutePage() {return m_pRecordset->GetAbsolutePage();};
	void SetAbsolutePage(int nPage) {m_pRecordset->PutAbsolutePage((enum PositionEnum)nPage);};
	long GetPageCount() {return m_pRecordset->GetPageCount();};
	long GetPageSize() {return m_pRecordset->GetPageSize();};
	void SetPageSize(int nSize) {m_pRecordset->PutPageSize(nSize);};
	long GetAbsolutePosition() {return m_pRecordset->GetAbsolutePosition();};
	void SetAbsolutePosition(int nPosition) {m_pRecordset->PutAbsolutePosition((enum PositionEnum)nPosition);};
	BOOL GetFieldInfo(CString strFieldName, Stru_AdoFieldInfo* fldInfo);
	BOOL GetFieldInfo(int nIndex, Stru_AdoFieldInfo* fldInfo);
	BOOL AppendChunk(CString strFieldName, LPVOID lpData, UINT nBytes);
	BOOL AppendChunk(int nIndex, LPVOID lpData, UINT nBytes);

	BOOL AppendChunk(CString strFieldName,CFile *pFile);
	BOOL AppendChunk(int nIndex, CFile *pFile);
	
	BOOL GetChunk(CString strFieldName, CString& strValue);
	BOOL GetChunk(int nIndex, CString& strValue);
	
	BOOL GetChunk(CString strFieldName, LPVOID pData);
	BOOL GetChunk(int nIndex, LPVOID pData);
	
	BOOL GetChunk(CString strFieldName, CFile *pFile);
	BOOL GetChunk(int nIndex, CFile *pFile);
	
	CString GetString(CString strCols, CString strRows, CString strNull, long numRows = 0);
	CString GetLastErrorString() {return m_strLastError;};
	DWORD GetLastError() {return m_dwLastError;};
	_variant_t GetBookmark() {return m_varBookmark = m_pRecordset->Bookmark;};
	BOOL SetBookmark(_variant_t varBookmark);
	BOOL Delete();
	BOOL IsConnectionOpen();
	_ConnectionPtr GetConnection();
	_RecordsetPtr GetRecordset() {return m_pRecordset;};
	operator _RecordsetPtr() {return m_pRecordset;};

	BOOL Clone(CADORecordset& pRst);
	BOOL Clone(_RecordsetPtr& pRst);

	BOOL SetFilter(CString strFilter);
	BOOL SetSort(CString strCriteria);
	BOOL SaveAsXML(CString strXMLFile);
	BOOL OpenXML(CString strXMLFile);
	BOOL Execute(CADOCommand& adoCommand);

	_variant_t GetRows();

protected:
	_RecordsetPtr m_pRecordset;
	int m_nSearchDirection;
	CString m_strFind;
	_variant_t m_varBookFind;
	_variant_t m_varBookmark;
	int m_nEditStatus;
	CString m_strLastError;
	DWORD m_dwLastError;
	void dump_com_error(_com_error &e);
	IADORecordBinding *m_pRecBinding;
	CString m_strQuery;

protected:
	BOOL PutFieldValue(CString strFieldName, _variant_t vtFld);
	BOOL PutFieldValue(_variant_t vtIndex, _variant_t vtFld);
	BOOL GetFieldInfo(_FieldPtr pField, Stru_AdoFieldInfo* fldInfo);
	BOOL GetChunk(_FieldPtr pField, CString& strValue);
	BOOL GetChunk(_FieldPtr pField, LPVOID lpData);
	BOOL GetChunk(_FieldPtr pField, CFile *pFile);
	BOOL AppendChunk(_FieldPtr pField, LPVOID lpData, UINT nBytes);
	BOOL SetChunkFromFile(_FieldPtr pField, CFile *pFile);	
};

class CADOParameter
{
public:

	enum Enum_AdoParameterDirection
	{
		adoParamUnknown = adParamUnknown,
		adoParamInput = adParamInput,
		adoParamOutput = adParamOutput,
		adoParamInputOutput = adParamInputOutput,
		adoParamReturnValue = adParamReturnValue 
	};

	CADOParameter()
	{
		m_pParameter = NULL;
		m_pParameter.CreateInstance(__uuidof(Parameter));
		m_pParameter->Direction = adParamUnknown;
		m_strName = _T("");
		m_pParameter->Name = m_strName.AllocSysString();
		m_pParameter->Type = adEmpty;
		m_pParameter->Size = 0;
	}
	CADOParameter(int nType, long lSize = 0, int nDirection = adoParamInput, CString strName = _T(""));
	CADOParameter(_ParameterPtr& para);
	CADOParameter(CADOParameter& adoPara);
	CADOParameter& operator=(_ParameterPtr& para);
	CADOParameter& operator=(CADOParameter& adoPara);

	~CADOParameter()
	{
		if(m_pParameter) m_pParameter.Release();
		m_pParameter = NULL;
		m_strName = _T("");
	}

	BOOL SetValue(int nValue);
	BOOL SetValue(bool bValue);
	BOOL SetValue(long lValue);
	BOOL SetValue(double dbValue);
	BOOL SetValue(CString strValue);
	BOOL SetValue(COleDateTime time);
	BOOL SetValue(_variant_t vtValue);
	BOOL GetValue(int& nValue);
	BOOL GetValue(long& lValue);
	BOOL GetValue(double& dbValue);
	BOOL GetValue(CString& strValue, CString strDateFormat = _T(""));
	BOOL GetValue(COleDateTime& time);
	BOOL GetValue(_variant_t& vtValue);
	void SetPrecision(int nPrecision) {m_pParameter->PutPrecision(nPrecision);};
	void SetScale(int nScale) {m_pParameter->PutNumericScale(nScale);};

	void SetName(CString strName) {m_strName = strName;};
	CString GetName() {return m_strName;};
	int GetType() {return m_nType;}
	_ParameterPtr GetParameter() {return m_pParameter;};
	operator _ParameterPtr() {return m_pParameter;};

protected:
	void dump_com_error(_com_error &e);
	
protected:
	_ParameterPtr m_pParameter;
	CString m_strName;
	int m_nType;
	CString m_strLastError;
	DWORD m_dwLastError;
};

class CADOCommand
{
public:
	enum Enum_AdoCommandType
	{
		adoCmdText = adCmdText,
		adoCmdTable = adCmdTable,
		adoCmdTableDirect = adCmdTableDirect,
		adoCmdStoredProc = adCmdStoredProc,
		adoCmdUnknown = adCmdUnknown,
		adoCmdFile = adCmdFile
	};

	CADOCommand()
	{
		m_pCommand = NULL;
		m_pCommand.CreateInstance(__uuidof(Command));
		m_pCommand->CommandText = "";
		m_pCommand->CommandType = adCmdText;
		m_nCommandType = adCmdText;
		m_nRecordsAffected = 0;
		m_strCommandText = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
	}
	CADOCommand(CADOConnection& adoConnection, CString strCommandText = _T(""), int nCommandType = adoCmdText);
	CADOCommand(_CommandPtr& cmd);
	CADOCommand(CADOCommand& adoCmd);
	CADOCommand& operator=(_CommandPtr& cmd);
	CADOCommand& operator=(CADOCommand& adoCmd);


	~CADOCommand()
	{
		if(m_pCommand) m_pCommand.Release();
		m_pCommand = NULL;
		m_nCommandType = adCmdText;
		m_nRecordsAffected = 0;
		m_strCommandText = _T("");
		m_strLastError = _T("");
		m_dwLastError = 0;
	}

	void SetText(CString strCommandText);
	void SetType(int nCommandType);
	int GetType() {return m_nCommandType;};
	BOOL RefreshParam();
	BOOL MakeInParam(CString strName, int nType, long lSize, _variant_t vtValue, int nPrecision = 0, int nScale = 0);
	BOOL MakeOutParam(CString strName, int nType, long lSize, _variant_t vtValue, int nPrecision = 0, int nScale = 0);
	BOOL AddParameter(CADOParameter* pAdoParameter);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, int nValue);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, bool bValue);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, long lValue);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, double dblValue, int nPrecision = 0, int nScale = 0);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, CString strValue);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, COleDateTime time);
	BOOL AddParameter(CString strName, int nType, int nDirection, long lSize, _variant_t vtValue, int nPrecision = 0, int nScale = 0);
	CString GetText() {return m_strCommandText;};
	void SetPrepared(BOOL bPrepared = TRUE);
	BOOL GetPrepared();
	int Execute(_RecordsetPtr& pRecordset);
	int Execute(CADORecordset& rst);
	int Execute();
	_CommandPtr GetCommand() {return m_pCommand;}
	operator _CommandPtr() {return m_pCommand;}
	_ConnectionPtr GetConnection() {return m_pCommand->ActiveConnection;};

protected:
	void dump_com_error(_com_error &e);

protected:
	_CommandPtr m_pCommand;
	int m_nCommandType;
	int m_nRecordsAffected;
	CString m_strCommandText;
	CString m_strLastError;
	DWORD m_dwLastError;
};

class CADOException : public CException
{
public:

	enum
	{
		noError,	// no error
		Unknown,	// unknown error
	};

	DECLARE_DYNAMIC(CADOException);
	
	CADOException(int nCause = 0, CString strErrorString = _T(""));
	virtual ~CADOException();

	static int GetError(int nADOError);

protected:
	int m_nCause;
	 CString m_strErrorString;
};

void AfxThrowADOException(int nADOError = 1000, CString strErrorString = _T(""));

#endif